﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Util;
using Model;
using UnityEngine;

using Logger = Util.Logger;

namespace Controllers
{
    public class AbstractAxisManipulator<T> : MonoBehaviour where T : AbstractManipulatorController
    {
        public Camera ScreenCamera;
        public T ManipulatorController;

        protected Color _axisColor;
        private bool _active = false;

        private void Start()
        {
            _axisColor = GetComponent<Renderer>().material.color;
            MouseInteraction.Get(gameObject).LeftDown.AddListener(OnLeftDown);
            MouseInteraction.Get(gameObject).LeftUp.AddListener(OnLeftUp);
        }

        private void OnLeftDown(Vector3 hit)
        {
            Active = true;
        }

        private void OnLeftUp(Vector3 hit)
        {
            Active = false;
        }

        public bool Active
        {
            get
            {
                return _active;
            }
            set
            {
                if (_active != value)
                {
                    if (value)
                        OnActive();
                    else
                        OnInActive();
                }
                _active = value;
            }
        }

        protected virtual void OnActive()
        {
            GetComponent<Renderer>().material.color = new Color(1, 1, 0, 64/255f);
        }

        protected virtual void OnInActive()
        {
            GetComponent<Renderer>().material.color = _axisColor;
        }
    }
}
