﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;
using Model;
using Model.World;

namespace Controllers
{
    public abstract class AbstractManipulatorController : MonoBehaviour
    {
        public GameObject Manipulator;
        public SelectedObject SelectedObject;
        public ManipulableObjects ManipulableObjects;
        public ManipulationModes ManipulationModes;
        public SceneNodes SceneNodes;

        public abstract ManipulationMode ManipulationMode
        {
            get;
        }

        public bool Active
        {
            get
            {
                return ManipulationMode == ManipulationModes.Current.Value && SelectedObject.Current.Value != null;
            }
        }

        protected virtual void Start()
        {
            SelectedObject.Current.AddListener((old, obj) => CheckActiveState());
            ManipulationModes.Current.AddListener((old, mode) => CheckActiveState());
            CheckActiveState();
        }

        protected virtual void CheckActiveState()
        {
            if (!Active)
            {
                Manipulator.SetActive(false);
                return;
            }

            var obj = SelectedObject.Current.Value;
            var node = obj.GetComponent<Node>();
            if (node != null)
            {
                Manipulator.transform.position = node.WorldPosition;
            }
            else
            {
                // A non-Node (Camera) was selected
                Manipulator.transform.position = obj.transform.position;
            }

            Manipulator.SetActive(true);
        }
    }
}
