﻿using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace Controllers
{
    /// <summary>
    /// Processes command inputs for the console window.
    /// </summary>
    public partial class CommandWindowController
    {
        private Regex commandSplitter = new Regex("\\s+");

        private void ProcessCommand()
        {
            // Splits the input text command line
            // Looks up the command and calls the command.
            var commandLine = InputText.text.Trim();
            var commandLineParts = commandSplitter.Split(commandLine);
            if (commandLineParts.Length == 0)
            {
                return;
            }
            try
            {
                Write("<b>>> " + commandLine + "</b>\n");
                if (!mCommands.ContainsKey(commandLineParts[0]))
                {
                    Error(string.Format("Unknown command: {0}", commandLineParts[0]));
                }
                else
                {
                    var command = mCommands[commandLineParts[0]];
                    command(commandLineParts);
                }
            }
            catch (Exception e)
            {
                Error(e.ToString());
            }
        }
    }

}