using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;

using Model;
using Model.World;
using UnityEngine;
using Logger = Util.Logger;
using Util;

namespace Controllers
{
    /// <summary>
    /// Implementations for commands.
    /// </summary>
    public partial class CommandWindowController
    {
        public SceneNodes SceneNodes;
        public SelectedObject SelectedObject;
        public TimelineController TheTimelineController;
        public ManipulationModes ManipulationModes;

        [ConsoleCommand("help", "Get help.")]
        private void CommandHelp()
        {
            Write("Commands:\n");
            Write("-------------------------------------\n");
            foreach (var pair in mCommandDescriptions)
            {
                Write(string.Format("  * {0}\n", pair.Value));
            }
        }

        [ConsoleCommand("clear", "Clear the console.")]
        private void CommandClear()
        {
            Clear();
        }

        [ConsoleCommand("exit", "Exit the application.")]
        private void CommandExit()
        {
            Application.Quit();
        }

        [ConsoleCommand("select", "Select a game object for editing.")]
        private void CommandSelectObject(string name)
        {
            var root = SceneNodes.Root;
            if (name == "none")
            {

                SelectedObject.Current.Value = null;
            }
            else if (Regex.IsMatch(name, "^\\d+$"))
            {
                // This is an integer.
                var id = Convert.ToInt32(name);
                var nodes = root.Descendants();
                if (id >= nodes.Count)
                {
                    Error("Could not find object by id: {0}", id);
                    return;
                }
                SelectedObject.Current.Value = nodes[id].gameObject;
            }
            else
            {
                var node = root.Descendants().FirstOrDefault(n => n.name == name);
                if (node == null)
                {
                    Error("Could not find object by name: {0}", name);
                    return;
                }
                SelectedObject.Current.Value = node.gameObject;
            }
        }

        [ConsoleCommand("list", "List game objects for editing.")]
        private void CommandSelectObject()
        {
            var nodes = SceneNodes.Root.Descendants();
            for (int i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                WriteLine(" * [{0}] {1}", i, node.name);
            }
        }

        [ConsoleCommand("manip_mode_set", "Set the manipulation mode.")]
        private void CommandManipulationModeSet(string mMode)
        {
            var newMode = (ManipulationMode) Enum.Parse(typeof(ManipulationMode), mMode);
            ManipulationModes.Current.Value = newMode;
        }

        [ConsoleCommand("dump-hierarchy", "Dumps info about the scene hierarchy.")]
        private void CommandDumpHierarchy(string fileName)
        {
            var details = GameObjectDebug.GetHierarchyDetails(SceneNodes.Root);
            var fPath = Path.GetFullPath(fileName);
            using (var fs = new StreamWriter(new FileStream(fPath, FileMode.Create), Encoding.UTF8))
            {
                fs.Write(details.ToString(true));
            }
            WriteLine("Wrote details to: {0}", fPath);
        }

        [ConsoleCommand("key_set", "Set the keyframe at timecode to the current state.")]
        private void CommandKeySet(double timecode)
        {
            TheTimelineController.CreateKeyframe(new Timecode(timecode));
        }

        [ConsoleCommand("key_get", "Set the state to the keyframe at timecode, or the interpolated keyframe at timecode.")]
        private void CommandKeyGet(double timecode)
        {
            TheTimelineController.CurrentTimecode = new Timecode(timecode);
        }

        [ConsoleCommand("key_rem", "Remove the keyframe at timecode.")]
        private void CommandKeyRem(double timecode)
        {
            TheTimelineController.RemoveKeyframe(new Timecode(timecode));
        }

        [ConsoleCommand("key_ls", "List the keyframes.")]
        private void CommandKeyLs()
        {
            foreach (var timecode in TheTimelineController.ListKeyframeTimecodes())
                WriteLine(" * {0}", timecode.ToString());
        }

        [ConsoleCommand("save", "Save the animation sequence to file.")]
        private void CommandSave(string fileName)
        {
            var fp = Path.GetFullPath(fileName);
            WriteLine("Writing animation to: {0}", fp);
            TheTimelineController.Save(fp);
        }

        [ConsoleCommand("load", "Load an animation sequence from file.")]
        private void CommandLoad(string fileName)
        {
            var fp = Path.GetFullPath(fileName);
            WriteLine("Loading animation from: {0}", fp);
            TheTimelineController.Load(fp);
        }
    }
}