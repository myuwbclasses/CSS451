﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Controllers
{
    /// <summary>
    /// Attribute to mark a method as an implementation of a command.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class ConsoleCommand : Attribute
    {
        public virtual string Name { get; private set; }
        public virtual string Description { get; private set; }

        public ConsoleCommand(string name, string description)
        {
            Name = name;
            Description = description;
        }
    }
}
