﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Controllers
{
    /// <summary>
    /// Gets the commands from the current class based on methods which have
    /// the ConsoleCommand attribute.
    /// </summary>
    public partial class CommandWindowController
    {
        /// <summary>
        /// Finds commands and adds the command functions and the descriptions to the command dictionaries.
        /// </summary>
        private void GetCommands()
        {
            foreach (var mi in typeof(CommandWindowController).GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
            {
                var commandAttrs = mi.GetCustomAttributes(typeof(ConsoleCommand), true);
                if (commandAttrs != null && commandAttrs.Length >= 1)
                {
                    ConsoleCommand consoleCommand = (ConsoleCommand)commandAttrs[0];
                    var cmdName = consoleCommand.Name;
                    mCommands[cmdName] = CompileToCommandRunner(mi);
                    mCommandDescriptions[cmdName] = GetCommandDescription(consoleCommand, mi);
                }
            }
        }

        /// <summary>
        /// Creates a help description for a command.
        /// </summary>
        private string GetCommandDescription(ConsoleCommand command, MethodInfo mi)
        {
            String description = command.Name;
            foreach (var p in mi.GetParameters())
            {
                description += " <" + p.Name + ">";
            }
            description += " - " + command.Description;
            return description;
        }

        /// <summary>
        /// Creates a function for executing a MethodInfo from a command line.
        /// </summary>
        private Func<string[], object> CompileToCommandRunner(MethodInfo mi)
        {
            var converters = GetParameterConverters(mi);
            return sParams => ExecuteCommandRunner(mi, converters, sParams);
        }

        /// <summary>
        /// Runs a command using the given method and parameter converters.
        /// </summary>
        private object ExecuteCommandRunner(MethodInfo mi, List<Func<string, object>> converters, String[] command)
        {
            if (converters.Count != command.Length - 1)
            {
                throw new ArgumentException("Invalid command.");
            }
            object[] parameters = new object[converters.Count];
            for (int i = 0; i < parameters.Length; i++)
            {
                parameters[i] = converters[i](command[i + 1]);
            }
            return mi.Invoke(this, parameters);
        }

        /// <summary>
        /// Get a list of converters based on method parameters.
        /// The convertes will convert string command line args to the types expected by a method.
        /// Only a few basic types are supported now, string, int, float, double, and bool.
        /// </summary>
        private List<Func<string, object>> GetParameterConverters(MethodInfo mi)
        {
            List<Func<string, object>> converters = new List<Func<string, object>>();

            foreach (var p in mi.GetParameters())
            {
                if (p.ParameterType == typeof(string))
                {
                    converters.Add(s => s);
                }
                else if (p.ParameterType == typeof(int))
                {
                    converters.Add(s => int.Parse(s));
                }
                else if (p.ParameterType == typeof(float))
                {
                    converters.Add(s => float.Parse(s));
                }
                else if (p.ParameterType == typeof(double))
                {
                    converters.Add(s => double.Parse(s));
                }
                else if (p.ParameterType == typeof(bool))
                {
                    converters.Add(s => bool.Parse(s));
                }
                else
                {
                    throw new ArgumentException(
                        string.Format("This command type has a paramter which cannot be auto converted - {0}.", mi));
                }
            }
            return converters;
        }
    }
}