﻿using System;
using System.Collections.Generic;

using Model.World;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Controllers
{
    /// <summary>
    /// Adds a console window for running commands.
    /// </summary>
    public partial class CommandWindowController : MonoBehaviour
    {
        public InputField InputText;
        public Text OutputText;

        private ScrollRect mScrollArea;
        private string mInitialGreeting;

        private bool mAllowEnter = false;
        private IDictionary<string, Func<string[], object>> mCommands = new Dictionary<string, Func<string[], object>>();
        private IDictionary<string, string> mCommandDescriptions = new SortedDictionary<string, string>();

        /// <summary>
        /// Toggle if the console window is visible or not.
        /// </summary>
        public void Toggle()
        {
            Active = !Active;
        }

        /// <summary>
        /// Get or set if the console window is visible and active.
        /// </summary>
        public bool Active
        {
            get
            {
                return gameObject.activeSelf;
            }
            set
            {
                gameObject.SetActive(value);
                if (value)
                {
                    // Puts the focus on the command input text box.
                    ActivateInput();
                }
            }
        }

        void Start()
        {
            // On start hide the console window and discover the commands available.
            gameObject.SetActive(false);
            mScrollArea = gameObject.GetComponentInChildren<ScrollRect>();
            mInitialGreeting = OutputText.text;
            GetCommands();
        }

        void Update()
        {
            // hack!
            // For some reason the InputText being focussed and the Return key being down
            // does not happen on the same update cycle.
            // I found an article about it with an approach to capture if input text is
            // focussed on the previous update cycle.
            // The goal here is to execute a command when enter is pressed in the input text box.
            if (mAllowEnter && InputText.text != "" && Input.GetKey(KeyCode.Return))
            {
                ProcessCommand();
                InputText.text = "";
                ActivateInput();
            }
            else
            {
                mAllowEnter = InputText.isFocused;
            }
        }
        
        // Write output to the console.
        private void Write(string text, params object[] args)
        {
            OutputText.text += string.Format(text, args);
            ScrollToBottom();
        }

        private void WriteLine(string text, params object[] args)
        {
            OutputText.text += string.Format(text, args) + "\n";
            ScrollToBottom();
        }

        // Writes an error message to the console.
        private void Error(string text, params object[] args)
        {
            OutputText.text += string.Format("\n<color=#ff0000>ERROR: {0}</color>\n", string.Format(text, args));
            ScrollToBottom();
        }

        // Clear the console.
        private void Clear()
        {
            OutputText.text = mInitialGreeting;
        }

        // Set focus on the command input text.
        private void ActivateInput()
        {
            InputText.Select();
            InputText.ActivateInputField();
        }

        private void ScrollToBottom()
        {
            StartCoroutine(EnqueueScrollToBottom());
        }

        private IEnumerator EnqueueScrollToBottom()
        {
            yield return new WaitForSeconds(0.1f);
            Canvas.ForceUpdateCanvases();
            mScrollArea.verticalScrollbar.value = 0f;
            Canvas.ForceUpdateCanvases();
        }
    }
}