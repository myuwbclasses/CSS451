﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Model;
using Model.World;
using Logger = Util.Logger;

namespace Controllers
{
    /// <summary>
    /// Handles inputs from the edit mode controls.
    /// </summary>
    public class EditModeControlsController : MonoBehaviour
    {
        public TimelineController TheTimelineController;
        public Editor Editor;

        void Start()
        {
            Editor.WatchMode(OnEditMode, OnPlayMode);
        }

        private void OnPlayMode()
        {
            this.gameObject.SetActive(false);
        }

        private void OnEditMode()
        {
            this.gameObject.SetActive(true);
        }
    }
}

