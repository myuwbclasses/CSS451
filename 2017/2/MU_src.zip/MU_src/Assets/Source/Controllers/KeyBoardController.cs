﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Model;
using Model.World;

namespace Controllers
{
    public class KeyBoardController : MonoBehaviour
    {
        public CommandWindowController CommandWindowController;
        public ManipulationModes ManipulationModes;

        void Update()
        {
            if (Input.GetKeyUp(KeyCode.Escape))
            {
                CommandWindowController.Toggle();
            }
            if (Input.GetKeyUp(KeyCode.F6))
            {
                ManipulationModes.Toggle();
            }
        }
    }
}
