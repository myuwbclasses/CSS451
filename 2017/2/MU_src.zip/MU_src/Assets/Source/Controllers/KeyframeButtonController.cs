﻿using UnityEngine;
using UnityEngine.UI;
using Logger = Util.Logger;

public class KeyframeButtonController : MonoBehaviour
{
    public Slider ParentSlider;
    public Timecode TheTimecode;

    public void Initialize()
    {
        GetComponent<RectTransform>().anchoredPosition += new Vector2(
            (ParentSlider.gameObject.GetComponent<RectTransform>().rect.width - 20) / ParentSlider.maxValue *
            TheTimecode.FTime, 0);
    }

    public void Click()
    {
        Logger.Debug("Jump to {0}", TheTimecode.ToString());
        ParentSlider.value = TheTimecode.FTime;
    }
}