﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using Model;
using Model.World;

namespace Controllers
{
    public class LookAtPositionController : MonoBehaviour
    {
        public Editor Editor;
        
        void Start()
        {
            Editor.WatchMode(OnEditMode, OnPlayMode);
        }

        void OnPlayMode()
        {
            gameObject.SetActive(false);
        }

        void OnEditMode()
        {
            gameObject.SetActive(true);
        }
    }
}