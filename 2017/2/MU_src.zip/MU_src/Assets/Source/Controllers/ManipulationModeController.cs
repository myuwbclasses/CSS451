﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using UnityEngine;
using UnityEngine.UI;

using Logger = Util.Logger;

namespace Controllers
{
    public class ManipulationModeController : MonoBehaviour
    {
        public ManipulationModes ManipulationModes;
        public Button RotationButton;
        public Button PositionButton;

        void Start()
        {
            ManipulationModes.Current.AddListener((old, mode) => OnManipulationModeChange());
            RotationButton.onClick.AddListener(() => SetMode(ManipulationMode.Rotation));
            PositionButton.onClick.AddListener(() => SetMode(ManipulationMode.Position));
            OnManipulationModeChange();
        }

        private void SetMode(ManipulationMode mode)
        {
            ManipulationModes.Current.Value = mode;
        }

        private void OnManipulationModeChange()
        {
            RotationButton.interactable = ManipulationMode.Rotation != ManipulationModes.Current.Value;
            PositionButton.interactable = ManipulationMode.Position != ManipulationModes.Current.Value;
        }
    }
}
