﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model.World;
using UnityEngine;
using UnityEngine.UI;

using Logger = Util.Logger;

namespace Controllers.Menu
{
    public abstract class AbstractMenuController : MonoBehaviour
    {
        private Dropdown _dropdown;
        private Dictionary<string, Action> _actions = new Dictionary<string, Action>();

        public string Title
        {
            get
            {
                return _dropdown.options[0].text;
            }
            set
            {
                _dropdown.options[0].text = value;
            }
        }

        protected virtual void Start()
        {
            _dropdown = gameObject.GetComponent<Dropdown>();
            var mainEntry = _dropdown.options[0];
            _dropdown.options.Clear();
            _dropdown.options.Add(mainEntry);
            _dropdown.onValueChanged.AddListener(OnDropdownValueChange);
            ConfigureMenu();
        }

        protected abstract void ConfigureMenu();

        protected void AddEntry(string name, Action action)
        {
            _dropdown.options.Add(new Dropdown.OptionData(name));
            _actions[name] = action;
        }

        private void OnDropdownValueChange(int v)
        {
            if (v == 0)
            {
                return;
            }
            var selectedEntry = _dropdown.options[v].text;
            _dropdown.value = 0;
            var f = _actions[selectedEntry];
            f();
        }
    }
}
