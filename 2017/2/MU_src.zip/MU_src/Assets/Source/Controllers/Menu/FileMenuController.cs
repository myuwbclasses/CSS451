﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using Util;
using UnityEngine;

namespace Controllers.Menu
{
    public class FileMenuController : AbstractMenuController
    {
        public TimelineController TimelineController;

        protected override void ConfigureMenu()
        {
            AddEntry("Open", OnOpen);
            AddEntry("Save", OnSave);
            AddEntry("Exit", OnExit);
        }

        private void OnOpen()
        {
            var f = FileDialog.GetReadableFile("Open Animation");
            if (f != null)
            {
                TimelineController.Load(f);
            }
        }

        private void OnSave()
        {
            var f = FileDialog.GetWritableFile("Save Animation");
            if (f != null)
            {
                TimelineController.Save(f);
            }
        }

        private void OnExit()
        {
            Application.Quit();
        }
    }
}
