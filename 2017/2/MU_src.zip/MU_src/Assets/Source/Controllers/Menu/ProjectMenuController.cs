﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using Util;
using UnityEngine;

using Logger = Util.Logger;
using System.Collections;

namespace Controllers.Menu
{
    public class ProjectMenuController : AbstractMenuController
    {
        public TimelineController TimeLineController;
        public Editor Editor;

        protected override void ConfigureMenu()
        {
            Logger.Info("ConfigureMenu");
            AddEntry("Play (Current)", () => OnPlay(false));
            AddEntry("Play (Beginning)", () => OnPlay(true));
            AddEntry("Delete Key Frame", DeleteKeyFrame);
            AddEntry("Reset", Reset);
        }

        private void DeleteKeyFrame()
        {
            TimeLineController.RemoveKeyframe(TimeLineController.CurrentTimecode);
        }

        private void Reset()
        {
            TimeLineController.Reset();
        }

        private void OnPlay(bool startFromBeginning)
        {
            StartCoroutine(EnqueuePlay(startFromBeginning));
        }

        private IEnumerator EnqueuePlay(bool startFromBeginning)
        {
            yield return new WaitForSeconds(0.4f);
            if (startFromBeginning)
            {
                TimeLineController.CurrentTimecode = new Timecode(0);
            }
            Editor.Mode.Value = EditorMode.Play;
        }
    }
}
