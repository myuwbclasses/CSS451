﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Model;
using Model.World;
using UnityEngine;
using Util;
using Logger = Util.Logger;

namespace Controllers
{
    /// <summary>
    /// Handles dispatching mouse inputs.
    /// </summary>
    public class MouseController : MonoBehaviour
    {
        static public readonly int Left = 0;
        static public readonly int Right = 1;

        static private readonly float MouseWheelSpeed = 10;
        static private readonly float KeyZoomSpeed = 10;
        static private readonly float TumbleMouseRatio = -0.1f;
        static private readonly float TrackMouseRatio = -0.1f;

        public MainCamera MainCamera;
        public Editor Editor;
        public SceneNodes SceneNodes;
        public SelectedObject SelectedObject;

        private MouseDrag _leftDrag;
        private MouseDrag _rightDrag;

        private HashSet<GameObject> _leftMouseWatchers = new HashSet<GameObject>();

        public MouseController()
        {
            _leftDrag = new MouseDrag(Left, AreCameraControlsActive);
            _rightDrag = new MouseDrag(Right, AreCameraControlsActive);
        }

        public bool AreCameraControlsActive()
        {
            return Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt);
        }

        void Update()
        {
            if (Editor.Mode.Value == EditorMode.Edit)
            {
                if (_leftDrag.Update())
                {
                    OnLeftDrag(_leftDrag.LastPosition, _leftDrag.CurrentPosition);
                }
                if (_rightDrag.Update())
                {
                    OnRightDrag(_rightDrag.LastPosition, _rightDrag.CurrentPosition);
                }
                CheckMouseWheel();
                CheckZoomKeys();
                CheckObjectMouseInteraction();
            }
        }

        private void CheckObjectMouseInteraction()
        {
            if (Input.GetMouseButtonDown(Left))
            {
                OnLeftMouseDown();
            }
            if (Input.GetMouseButtonUp(Left))
            {
                OnLeftMouseUp();
            }
        }

        private void OnLeftMouseUp()
        {
            var pos = Input.mousePosition;
            foreach (var obj in _leftMouseWatchers)
            {
                Logger.Debug("MouseUp: {0} at {1}.", obj.name, pos);
                var mi = obj.GetComponent<MouseInteraction>();
                if (mi != null)
                {
                    mi.LeftUp.Fire(pos);
                }
            }
            _leftMouseWatchers.Clear();
        }

        private void OnLeftMouseDown()
        {
            // Check normal objects.
            var hit = MouseSupport.GetRaycastHit();
            if (hit != null && hit.Value.collider.gameObject.GetComponent<Node>() != null)
            {
                // This is actually a primitive node ignore this type of hit.
                hit = null;
            }

            // Check node primitives.
            var nodes = SceneNodes.Root.Descendants().OfType<NodePrimitive>();
            NodeRayCastHit nodeHit = null;

            // For now only support mouse down for node primitives.
            if (Input.GetMouseButtonDown(Left))
            {
                nodeHit = NodeRayCast.GetHit2(nodes);
            }

            // If both types of objects are hit we have to see which hit is closer.
            if (hit != null && nodeHit != null)
            {
                var objDist = hit.Value.distance;
                var nodeDist = (nodeHit.hit - nodeHit.ray.origin).magnitude;
                if (objDist < nodeDist)
                {
                    OnStandardGameObjectMouseDown(hit.Value);
                }
                else
                {
                    OnNodePrimitiveMouseDown(nodeHit);
                }
            }
            else if (hit != null)
            {
                OnStandardGameObjectMouseDown(hit.Value);
            }
            else if (nodeHit != null)
            {
                OnNodePrimitiveMouseDown(nodeHit);
            }
        }

        private void OnNodePrimitiveMouseDown(NodeRayCastHit hit)
        {
            OnMouseDown(hit.node.gameObject, hit.hit);
        }

        private void OnStandardGameObjectMouseDown(RaycastHit hit)
        {
            OnMouseDown(hit.collider.gameObject, hit.point);
        }

        private void OnMouseDown(GameObject obj, Vector3 hitPosition)
        {
            Logger.Debug("MouseDown: {0} at {1}", obj.name, hitPosition);
            var mi = obj.GetComponent<MouseInteraction>();
            if (mi != null)
            {
                mi.LeftDown.Fire(hitPosition);
                _leftMouseWatchers.Add(obj);
            }
        }

        private void CheckMouseWheel()
        {
            var d = Input.GetAxis("Mouse ScrollWheel");
            MainCamera.Zoom(d * MouseWheelSpeed);
        }

        private void CheckZoomKeys()
        {
            if (Input.GetKey(KeyCode.PageUp))
            {
                MainCamera.Zoom(KeyZoomSpeed * Time.deltaTime);
            }
            if (Input.GetKey(KeyCode.PageDown))
            {
                MainCamera.Zoom(-KeyZoomSpeed * Time.deltaTime);
            }
        }

        private void OnLeftDrag(Vector3 lastPos, Vector3 currentPos)
        {
            var delta = currentPos - lastPos;
            MainCamera.Tumble(delta.y * TumbleMouseRatio, delta.x * TumbleMouseRatio);
        }

        private void OnRightDrag(Vector3 lastPos, Vector3 currentPos)
        {
            var delta = currentPos - lastPos;
            MainCamera.Track(delta.x * TrackMouseRatio, delta.y * TrackMouseRatio);
        }
    }
}