﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using UnityEngine;
using Util;

using Logger = Util.Logger;

namespace Model
{
    /// <summary>
    ///     Adds behavior for NodePrimitives.
    /// </summary>
    public class NodePrimitiveMouseController : MonoBehaviour
    {
        public SelectedObject SelectedObject;
        public SceneNodes SceneNodes;

        /// <summary>
        ///     On starupt register all node primitives for left click object selection.
        /// </summary>
        void Start()
        {
            foreach (var node in SceneNodes.Root.Descendants())
            {
                var np = node as NodePrimitive;
                if (np != null)
                {
                    MouseInteraction.Get(node.gameObject).LeftUp.AddListener(hit => OnLeftMouseClick(np, hit));
                }
            }
        }

        /// <summary>
        ///     When a node is clicked select (or de-select) it.
        /// </summary>
        /// <param name="node"></param>
        /// <param name="hit"></param>
        private void OnLeftMouseClick(NodePrimitive node, Vector3 hit)
        {
            Logger.Debug("Node hit: {0} at {1}.", gameObject.name, hit);
            var selected = SelectedObject.Current.Value;
            var sceneNode = node.GetParentSceneNode();

            // If the user clicks the same object it will be de-selected.
            if (selected == sceneNode.gameObject)
            {
                SelectedObject.Current.Value = null;
            }
            else
            {
                // Set the parent scene node as the currently selected value.
                SelectedObject.Current.Value = sceneNode.gameObject;
            }
        }
    }
}
