﻿using System.Collections;
using System.Collections.Generic;

using Model;
using Model.World;
using Util;
using UnityEngine;

/// <summary>
///     Hooks left mouse clicks for hte camera visualation component to make the camera selected.
/// </summary>
public class PlayCameraVisualizerController : MonoBehaviour
{
    public SelectedObject SelectedObject;

    void Start()
    {
        MouseInteraction.Get(gameObject).LeftUp.AddListener(OnLeftClick);
    }
    
    private void OnLeftClick(Vector3 hit)
    {
        var selected = SelectedObject.Current.Value;

        // If the user clicks the same object it will be de-selected.
        if (selected == transform.parent.gameObject)
        {
            SelectedObject.Current.Value = null;
        }
        else
        {
            // Set the parent scene node as the currently selected value.
            SelectedObject.Current.Value = transform.parent.gameObject;
        }
    }
}
