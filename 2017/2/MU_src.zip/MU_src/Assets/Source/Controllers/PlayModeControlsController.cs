﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using Model;
using Model.World;

namespace Controllers
{
    /// <summary>
    /// Handles inputs from the play mode controls.
    /// </summary>
    public class PlayModeControlsController : MonoBehaviour
    {
        public Button StopButton;
        public TimelineController TheTimelineController;
        public Editor Editor;

        void Start()
        {
            StopButton.onClick.AddListener(OnStop);
            Editor.WatchMode(OnEditMode, OnPlayMode);
        }

        private void OnStop()
        {
            if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
                TheTimelineController.CurrentTimecode = new Timecode();
            Editor.Mode.Value = EditorMode.Edit;
        }

        private void OnPlayMode()
        {
            this.gameObject.SetActive(true);
        }

        private void OnEditMode()
        {
            this.gameObject.SetActive(false);
        }
    }
}
