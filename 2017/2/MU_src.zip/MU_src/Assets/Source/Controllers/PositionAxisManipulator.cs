﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

using Logger = Util.Logger;

namespace Controllers
{
    public class PositionAxisManipulator : AbstractAxisManipulator<PositionManipulatorController>
    {
        private DragReference _dragReference = null;

        protected override void OnActive()
        {
            base.OnActive();
            if (_dragReference == null)
            {
                _dragReference = new DragReference(this, ManipulatorController.SetNewPosition);
            }
        }

        protected override void OnInActive()
        {
            base.OnInActive();
            _dragReference = null;
        }

        private void Update()
        {
            if (!ManipulatorController.Active)
            {
                _dragReference = null;
                return;
            }

            if (_dragReference == null)
                return;

            _dragReference.Update();
        }

        /// <summary>
        /// This class handles moving the manipulator.
        /// </summary>
        internal class DragReference
        {
            /**
             * How this class works:
             * 
             * When the mouse is pressed down the class will record where the axis currently is
             * in the world and where it is in screen cooridnates. It will also record where the
             * mouse position was at the first time of the click. From this data it computes the
             * shortest distance along the axis in screen coordinates form the mouse position.
             * 
             * When ever the mouse is then moved the manipulator will be moved in relation to the
             * original reference point.
             */

            private Vector3 _axisStartWorld;
            private Vector3 _axisEndWorld;
            private Vector3 _axisStartScreen;
            private Vector3 _axisEndScreen;
            private Vector3 _screenV;
            private Vector3 _worldV;
            private float _worldScreenRatio;
            private float _dragOffset;

            private PositionAxisManipulator _controller;
            private Action<Vector3> _newPositionHandler;

            public DragReference(PositionAxisManipulator controller, Action<Vector3> newPositionHandler)
            {
                // Compute the variables needed to calculate a new postion when the mouse moves.
                _controller = controller;
                _newPositionHandler = newPositionHandler;

                _axisStartWorld = _controller.transform.parent.position;
                _axisEndWorld = _controller.transform.position;
                _axisStartScreen = _controller.ScreenCamera.WorldToScreenPoint(_axisStartWorld);
                _axisEndScreen = _controller.ScreenCamera.WorldToScreenPoint(_axisEndWorld);
                _screenV = (_axisEndScreen - _axisStartScreen).normalized;
                _worldV = (_axisEndWorld - _axisStartWorld).normalized;
                var VA = Input.mousePosition - _axisStartScreen;
                _dragOffset = Vector3.Dot(VA, _screenV);

                _worldScreenRatio = (_axisEndWorld - _axisStartWorld).magnitude / (_axisEndScreen - _axisStartScreen).magnitude;
            }

            public void Update()
            {
                // Get the distance along the axis in screen space.
                var VA = Input.mousePosition - _axisStartScreen;
                var d = Vector3.Dot(VA, _screenV);

                // Take off the initial distance (dragOffset).
                // This gives how much to move along the axis.
                var delta = d - _dragOffset;

                // Compute the new workd position for the manipulator.
                var newWorldPos = _axisStartWorld + delta * _worldScreenRatio * _worldV;

                // Now move the vertex to a world cooridnate.
                _newPositionHandler(newWorldPos);
            }
        }

    }
}
