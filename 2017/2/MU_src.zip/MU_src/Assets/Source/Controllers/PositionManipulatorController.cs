﻿using System;
using System.Collections;
using System.Collections.Generic;

using Model;
using Model.World;
using UnityEngine;
using Util;

using Logger = Util.Logger;

namespace Controllers
{
    public class PositionManipulatorController : AbstractManipulatorController
    {
        public override ManipulationMode ManipulationMode
        {
            get
            {
                return ManipulationMode.Position;
            }
        }

        public void SetNewPosition(Vector3 pos)
        {
            Manipulator.transform.position = pos;

            var obj = SelectedObject.Current.Value;
            var node = obj.GetComponent<Node>();
            if (node != null)
            {
                SetNodePosition(node, pos);
            }
            else
            {
                SetGameObjectPosition(obj, pos);
            }

            // Let others know that the game object has changed.
            ManipulableObjects.GameObjectChangeEvent.Fire(obj);
        }

        private void SetNodePosition(Node node, Vector3 pos)
        {
            node.WorldPosition = pos;
        }

        private void SetGameObjectPosition(GameObject obj, Vector3 pos)
        {
            obj.transform.position = pos;
        }
    }
}