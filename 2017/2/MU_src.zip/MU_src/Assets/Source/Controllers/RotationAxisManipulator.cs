﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using UnityEngine;
using Util;

using Logger = Util.Logger;

namespace Controllers
{
    public class RotationAxisManipulator : AbstractAxisManipulator<RotationManipulatorController>
    {
        private DragReference _dragReference = null;

        protected override void OnActive()
        {
            base.OnActive();
            if (_dragReference == null)
            {
                _dragReference = new DragReference(this);
            }
        }

        protected override void OnInActive()
        {
            base.OnInActive();
            _dragReference = null;
        }

        private void Update()
        {
            if (!ManipulatorController.Active)
            {
                OnInActive();
                return;
            }

            if (_dragReference == null)
                return;

            _dragReference.Update();
        }

        public void SetRotation(Quaternion rotation)
        {
            ManipulatorController.SetRotation(rotation);
        }

        /// <summary>
        /// This class handles moving the manipulator.
        /// </summary>
        internal class DragReference
        {
            private Vector3 _axisCenterWorld;
            private Vector3 _axisReferenceWorld;
            private Vector3 _axisNormal;
            private Quaternion _originalManipulatorRotation;
            private RotationAxisManipulator _controller;

            public DragReference(RotationAxisManipulator controller)
            {
                _controller = controller;
                _axisCenterWorld = _controller.transform.parent.position;
                _axisNormal = _controller.transform.up;
                _axisReferenceWorld = GetAxisWorldIntersectionPoint().Value;
                _originalManipulatorRotation = _controller.ManipulatorController.Manipulator.transform.localRotation;
            }

            public void Update()
            {
                // Get a point where the mouse ray intercepts the plan the axis object is in.
                var mouseWorldPoint = GetAxisWorldIntersectionPoint();

                if (!mouseWorldPoint.HasValue)
                    return;

                var r = Quaternion.FromToRotation(_axisReferenceWorld - _axisCenterWorld, mouseWorldPoint.Value - _axisCenterWorld);
                _controller.SetRotation(r * _originalManipulatorRotation);
            }
            
            private Vector3? GetAxisWorldIntersectionPoint()
            {
                // Line to plane intersection.
                var ray = _controller.ScreenCamera.ScreenPointToRay(Input.mousePosition);
                return Intersect.LineToPlane(ray.origin, ray.direction, _axisNormal, _axisCenterWorld);
            }
        }
    }
}
