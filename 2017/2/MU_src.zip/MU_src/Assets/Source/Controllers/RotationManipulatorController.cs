﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using UnityEngine;

namespace Controllers
{
    public class RotationManipulatorController : AbstractManipulatorController
    {
        public override ManipulationMode ManipulationMode
        {
            get
            {
                return ManipulationMode.Rotation;
            }
        }

        protected override void CheckActiveState()
        {
            base.CheckActiveState();
            if (!Active)
            {
                return;
            }
            var obj = SelectedObject.Current.Value;
            Manipulator.transform.rotation = obj.transform.rotation;
        }

        public void SetRotation(Quaternion rotation)
        {
            Manipulator.transform.rotation = rotation;
            var obj = SelectedObject.Current.Value;
            if (obj != null)
            {
                obj.transform.rotation = rotation;

                // Let others know that the game object has changed.
                ManipulableObjects.GameObjectChangeEvent.Fire(obj);
            }
        }
    }
}
