﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using UnityEngine;

using Logger = Util.Logger;

namespace Controllers
{
    /// <summary>
    /// Change the state of an alpha block when it collides with something.
    /// </summary>
    public class SingleCollisionAlphaBlockController : SingleCollisionDetectionController
    {
        private Material[] _originalMaterials = null;
        public Material[] CollisionMaterials = null;

        protected override void Start()
        {
            base.Start();
            var renderer = gameObject.GetComponent<MeshRenderer>();
            _originalMaterials = renderer.materials;

        }

        protected override void OnCollision()
        {
            var renderer = gameObject.GetComponent<MeshRenderer>();
            _originalMaterials = renderer.materials;
            renderer.materials = CollisionMaterials;
        }

        protected override void OnReset()
        {
            var renderer = gameObject.GetComponent<MeshRenderer>();
            renderer.materials = _originalMaterials;
        }
    }
}
