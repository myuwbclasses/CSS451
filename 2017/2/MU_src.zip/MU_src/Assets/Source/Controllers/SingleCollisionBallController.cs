﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using UnityEngine;

namespace Controllers
{
    /// <summary>
    /// Change the state of the Ball when it collides with something.
    /// </summary>
    public class SingleCollisionBallController : SingleCollisionDetectionController
    {
        public Color CollideColor = Color.white;
        private Color _originalColor;

        protected override void Start()
        {
            base.Start();
            _originalColor = gameObject.GetComponent<NodePrimitive>().MyColor;
        }

        protected override void OnCollision()
        {
            var np = gameObject.GetComponent<NodePrimitive>();
            np.MyColor = CollideColor;
        }

        protected override void OnReset()
        {
            var np = gameObject.GetComponent<NodePrimitive>();
            np.MyColor = _originalColor;
        }
    }
}
