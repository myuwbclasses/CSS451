﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Model.World;
using UnityEngine;
using Util;
using Util.Collide;

using Logger = Util.Logger;

namespace Controllers
{
    /// <summary>
    /// When a collision is detected the first time in a play sequence between this game object
    /// and another in the CollidableObjects list, this game object will change in some way.
    /// </summary>
    public abstract class SingleCollisionDetectionController : MonoBehaviour
    {
        public List<Node> CollidableObjects = new List<Node>();
        public Editor Editor;

        private MeshObjectCollider _collider;
        private bool _collisionAlreadyDetected = false;

        protected virtual void Start()
        {
            _collider = MeshObjectCollider.Get(gameObject);
            Editor.Mode.AddListener((old, mode) => OnModeChange());
        }

        void OnModeChange()
        {
            _collisionAlreadyDetected = false;
            OnReset();
        }

        void Update()
        {
            if (Time.frameCount <= 1 || _collisionAlreadyDetected || Editor.Mode.Value != EditorMode.Play)
            {
                return;
            }
            foreach (var obj in CollidableObjects)
            {
                if (_collider.CollidesWith(MeshObjectCollider.Get(obj.gameObject)))
                {
                    _collisionAlreadyDetected = true;
                    OnCollision();
                    return;
                }
            }
        }

        protected virtual void OnCollision()
        {
        }

        protected virtual void OnReset()
        {
        }
    }
}
