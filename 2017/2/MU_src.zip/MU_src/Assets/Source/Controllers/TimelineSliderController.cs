﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimelineSliderController : MonoBehaviour
{
    public TimelineController TheTimelineController;
    public KeyframeButtonController KeyframeButtonControllerPrototype;
    private Slider _slider;
    private bool _supressChange = false;
    private List<KeyframeButtonController> _keyframeButtons = new List<KeyframeButtonController>();

    // Use this for initialization
    void Start ()
    {
        _slider = GetComponent<Slider>();
        if (_slider == null)
            throw new NullReferenceException("No slider component found by TimelineSliderController");

        _slider.minValue = 0;
        _slider.maxValue = TheTimelineController.Length.FTime;

        TheTimelineController.KeyframeModified += TheTimelineController_KeyframeModified;
        TheTimelineController_KeyframeModified(null, null);
    }

    private void TheTimelineController_KeyframeModified(object sender, EventArgs e)
    {
        foreach (var keyframeButton in _keyframeButtons)
            Destroy(keyframeButton.gameObject);
        _keyframeButtons.Clear();

        foreach (var timecode in TheTimelineController.ListKeyframeTimecodes())
        {
            var keyframeButton = Instantiate(KeyframeButtonControllerPrototype);
            keyframeButton.TheTimecode = timecode;
            keyframeButton.gameObject.GetComponent<RectTransform>().SetParent(gameObject.GetComponent<RectTransform>());
            keyframeButton.gameObject.SetActive(true);
            keyframeButton.gameObject.GetComponent<RectTransform>().anchoredPosition =
                KeyframeButtonControllerPrototype.GetComponent<RectTransform>().anchoredPosition;
            keyframeButton.Initialize();
            _keyframeButtons.Add(keyframeButton);
        }
    }

    public void OnValueChange()
    {
        if (_supressChange)
            return;

        try
        {
            TheTimelineController.CurrentTimecode = new Timecode(_slider.value);
        }
        catch (TimelineController.TimelineElapsedException)
        {
            _supressChange = true;
            _slider.value = TheTimelineController.Length.FTime;
            _supressChange = false;
        }
    }
    
    // Update is called once per frame
    void Update ()
    {
        _supressChange = true;
        _slider.value = TheTimelineController.CurrentTimecode.FTime;
        _supressChange = false;
    }
}
