namespace Model
{
    // The mode for the editor.
    public enum EditorMode { Edit, Play };
}