﻿using System;
using System.Collections.Generic;
using UnityEngine;

// ReSharper disable CheckNamespace
// ReSharper disable UseNameofExpression

/// <summary>
///     A keyframe representing the transformation state of all objects at a given point in time
/// </summary>
public class Keyframe
{
    /// <summary>
    ///     The KeyframeTransforms applied at this Keyframe
    /// </summary>
    public List<KeyframeTransform> KeyframeTransforms;

    /// <summary>
    ///     The timecode at which this Keyframe occurs
    /// </summary>
    public Timecode TheTimecode;

    /// <summary>
    ///     Create a new Keyframe with the given timecode
    /// </summary>
    /// <param name="timecode">Timecode to set</param>
    public Keyframe(Timecode timecode)
    {
        TheTimecode = timecode;
        KeyframeTransforms = new List<KeyframeTransform>();
    }

    /// <summary>
    ///     Interpolate between two Keyframe
    /// </summary>
    /// <param name="start">Starting Keyframe</param>
    /// <param name="end">Ending Keyframe</param>
    /// <param name="timecode">Timecode to interpolate on, rounded to two decimal places</param>
    /// <returns>Interpolated KeyframeTransform</returns>
    public static Keyframe Interpolate(Keyframe start,
        Keyframe end, Timecode timecode)
    {
        if (start.TheTimecode.Time >= end.TheTimecode.Time)
            throw new ArgumentOutOfRangeException("start",
                "Starting Keyframe occurs before or at the same time as ending Keyframe");
        if (timecode < start.TheTimecode || timecode > end.TheTimecode)
            throw new ArgumentOutOfRangeException("timecode",
                "Given timecode is outside of the range defined by starting and ending keyframes");

        var interpolatedKeyframe = new Keyframe(timecode);
        var timeDelta = (timecode - start.TheTimecode) / (end.TheTimecode - start.TheTimecode);

        foreach (var startKt in start.KeyframeTransforms)
        {
            var endKt = end.KeyframeTransforms.Find(t =>
                t.TheGameObject == startKt.TheGameObject);

            var iTrans = startKt.Translation +
                         (endKt.Translation - startKt.Translation) *
                         timeDelta.FTime;
            var iRot = Quaternion.Slerp(startKt.Up, endKt.Up, timeDelta.FTime);

            interpolatedKeyframe.KeyframeTransforms.Add(
                new KeyframeTransform(startKt.TheGameObject,
                    iTrans, iRot));
        }

        return interpolatedKeyframe;
    }

    /// <summary>
    ///     Structure to store transformation of a GameObject for a Keyframe
    /// </summary>
    public struct KeyframeTransform
    {
        /// <summary>
        ///     The GameObject this KeyframeTransform applies to
        /// </summary>
        public GameObject TheGameObject;

        /// <summary>
        ///     The translation of this KeyframeTransform
        /// </summary>
        public Vector3 Translation;

        /// <summary>
        ///     The Up of this KeyframeTransform
        /// </summary>
        public Quaternion Up;

        /// <summary>
        ///     Create a new KeyframeTransform
        /// </summary>
        /// <param name="gameObject">The GameObject this KeyframeTransform applies to</param>
        /// <param name="translation">The translation of this KeyframeTransform</param>
        /// <param name="rotation">The rotation of this KeyframeTransform</param>
        /// <exception cref="ArgumentNullException">Null GameObject provided</exception>
        public KeyframeTransform(GameObject gameObject,
            Vector3 translation = default(Vector3),
            Quaternion rotation = default(Quaternion))
        {
            if (gameObject == null)
                throw new ArgumentNullException("gameObject",
                    "A keyframe cannot be created for a null GameObject");

            TheGameObject = gameObject;

            Translation = translation;
            Up = rotation;
        }
    }
}