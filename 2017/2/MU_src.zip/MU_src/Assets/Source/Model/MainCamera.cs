﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Util;

namespace Model
{
    
    public class MainCamera : MonoBehaviour
    {
        static private float ZoomTolerance = 0.1f;

        public WatchableAttribute<Vector3> LookAtPosition = new WatchableAttribute<Vector3>(Vector3.zero);
        public GameObject LookAtObject;

        void Start()
        {
            LookAtPosition.Value = LookAtObject.transform.localPosition;
            LookAtPosition.AddListener((oldP, newP) => SetLookAtPosition(newP));
        }

        void Update()
        {
            LookTowards();
        }

        public void Zoom(float magnitude)
        {
            var dir = LookAtObject.transform.localPosition - transform.localPosition;
            var dist = dir.magnitude;
            if (magnitude < (dist - ZoomTolerance))
            {
                transform.localPosition = transform.localPosition + magnitude * (dir / dist);
            }
        }

        public void Track(float xDelta, float yDelta)
        {
            var v = xDelta * transform.right + yDelta * transform.up;
            transform.localPosition = transform.localPosition + v;
            LookAtPosition.Value = LookAtPosition.Value + v;
        }

        public void Tumble(float upDegrees, float rightDegrees)
        {
            // Check if tumbling goes too far.
            var angle = Mathf.Acos(Vector3.Dot(transform.forward.normalized, Vector3.down)) * Mathf.Rad2Deg;
            if ((upDegrees > 0 && (angle - upDegrees) <= 1) ||
                (upDegrees < 0 && (angle - upDegrees) >= 179))
            {
                return;
            }

            Quaternion q =
                Quaternion.AngleAxis(-rightDegrees, transform.up) *
                Quaternion.AngleAxis(upDegrees, transform.right);
            
            Matrix4x4 r = Matrix4x4.TRS(Vector3.zero, q, Vector3.one);
            Matrix4x4 invP = Matrix4x4.TRS(-LookAtObject.transform.localPosition, Quaternion.identity, Vector3.one);
            r = invP.inverse * r * invP;
            Vector3 newCameraPos = r.MultiplyPoint(transform.localPosition);

            transform.localPosition = newCameraPos;
            LookTowards();
        }

        private void SetLookAtPosition(Vector3 pos)
        {
            LookAtObject.transform.localPosition = pos;
            LookTowards();
        }

        private void LookTowards()
        {
            transform.up = Vector3.up;
            Vector3 V = LookAtObject.transform.localPosition - transform.localPosition;
            Vector3 W = Vector3.Cross(V, transform.up);
            Vector3 U = Vector3.Cross(W, V);
            transform.localRotation = Quaternion.LookRotation(V, U);
        }
    }
}

