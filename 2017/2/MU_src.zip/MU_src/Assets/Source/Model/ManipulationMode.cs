﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    /// <summary>
    /// How are selected objects manipulated?
    /// </summary>
    public enum ManipulationMode { Position, Rotation };
}
