﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Util;
using UnityEngine;

namespace Model
{
    /// <summary>
    /// Used with MouseController to handle mouse events well with mixed SceneNode, NodePrimites, and game objects.
    /// </summary>
    public class MouseInteraction : MonoBehaviour
    {
        public readonly ApplicationEvent<Vector3> LeftUp = new ApplicationEvent<Vector3>();
        public readonly ApplicationEvent<Vector3> LeftDown = new ApplicationEvent<Vector3>();

        public static MouseInteraction Get(GameObject obj)
        {
            var mi = obj.GetComponent<MouseInteraction>();
            if (mi == null)
            {
                mi = obj.AddComponent<MouseInteraction>();
            }
            return mi;
        }
    }
}
