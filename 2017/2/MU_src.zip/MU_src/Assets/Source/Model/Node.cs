﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Model
{
    /// <summary>
    ///     Base class for SceneNode and NodePrimitive.
    /// </summary>
    public abstract class Node : MonoBehaviour
    {
        /// <summary>
        /// The pivot for the scene.
        /// </summary>
        public Vector3 Pivot = Vector3.zero;

        /// <summary>
        /// Gets the transformation matrix for this node.
        /// </summary>
        /// <returns></returns>
        public abstract Matrix4x4 GetMatrix();

        /// <summary>
        /// Get the inverse transformation matrix.
        /// </summary>
        /// <returns></returns>
        public abstract Matrix4x4 GetInverseMatrix();

        /// <summary>
        /// Gets the parent SceneNode.
        /// </summary>
        public virtual SceneNode GetParentSceneNode()
        {
            var t = transform.parent;
            while (t != null)
            {
                var node = t.gameObject.GetComponent<SceneNode>();
                if (node != null)
                {
                    return node;
                }
                t = t.parent;
            }
            return null;
        }

        /// <summary>
        ///     Gets and sets the world position of a node.
        /// </summary>
        public abstract Vector3 WorldPosition
        {
            set;
            get;
        }
    }
}
