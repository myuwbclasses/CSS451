﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Util;

namespace Model
{
    public class NodePrimitive: Node
    {
        public Color MyColor = new Color(0.1f, 0.1f, 0.2f, 1.0f);

        void OnDestroy()
        {
            GetParentSceneNode().PrimitiveList.Remove(this);
        }

        public override Matrix4x4 GetMatrix()
        {
            var m = GetParentSceneNode().GetMatrix();
            return GetMatrix(ref m);
        }

        public void LoadShaderMatrix(ref Matrix4x4 nodeMatrix)
        {
            Matrix4x4 m = GetMatrix(ref nodeMatrix);
            GetComponent<Renderer>().material.SetMatrix("MyXformMat", m);
            GetComponent<Renderer>().material.SetColor("MyColor", MyColor);
        }

        private Matrix4x4 GetMatrix(ref Matrix4x4 nodeMatrix)
        {
            Matrix4x4 p = Matrix4x4.TRS(Pivot, Quaternion.identity, Vector3.one);
            Matrix4x4 invp = Matrix4x4.TRS(-Pivot, Quaternion.identity, Vector3.one);
            Matrix4x4 trs = Matrix4x4.TRS(transform.localPosition, transform.localRotation, transform.localScale);
            return nodeMatrix * p * trs * invp;
        }

        /// <summary>
        ///     Get the inverse transformation matrix.
        /// </summary>
        /// <returns></returns>
        public override Matrix4x4 GetInverseMatrix()
        {
            var t = Matrix4x4.TRS(-transform.localPosition, Quaternion.identity, Vector3.one);
            var r = Matrix4x4.TRS(Vector3.zero, Quaternion.Inverse(transform.localRotation), Vector3.one);
            var s = Matrix4x4.TRS(
                Vector3.zero,
                Quaternion.identity,
                new Vector3(
                    1 / transform.localScale.x,
                    1 / transform.localScale.y,
                    1 / transform.localScale.z));

            Matrix4x4 p = Matrix4x4.TRS(Pivot, Quaternion.identity, Vector3.one);
            var invPivot = Matrix4x4.TRS(-Pivot, Quaternion.identity, Vector3.one);  // inv Pivot

            return p * s * r * t * invPivot * GetParentSceneNode().GetInverseMatrix();
        }

        /// <summary>
        ///     Gets and sets the position of a NodePrimitive.
        /// </summary>
        public override Vector3 WorldPosition
        {
            set
            {
                var parent = GetParentSceneNode();
                var invM = (parent == null) ? Matrix4x4.identity : parent.GetInverseMatrix();
                var m = (parent == null) ? Matrix4x4.identity : parent.GetMatrix();

                var localPos = invM.MultiplyPoint(value) - this.Pivot;
                transform.localPosition = localPos;
            }
            get
            {
                return GetMatrix().MultiplyPoint(this.Pivot);
            }
        }
    }
}