﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using Util;

namespace Model
{
    public class SceneNode : Node
    {
        // The transform matrix for this scene node.
        protected Matrix4x4 mCombinedParentXform;

        private List<NodePrimitive> _primitiveList;

        public List<NodePrimitive> PrimitiveList
        {
            get
            {
                AddPrimitives();
                return _primitiveList;
            }
        }

        void Start()
        {
            AddPrimitives();
            mCombinedParentXform = Matrix4x4.identity;
        }

        public override Matrix4x4 GetMatrix()
        {
            return mCombinedParentXform;
        }

        /// <summary>
        ///     Gets the inverse transformation matrix.
        /// </summary>
        /// <returns></returns>
        public override Matrix4x4 GetInverseMatrix()
        {
            var t = Matrix4x4.TRS(-transform.localPosition, Quaternion.identity, Vector3.one);
            var r = Matrix4x4.TRS(Vector3.zero, Quaternion.Inverse(transform.localRotation), Vector3.one);
            var s = Matrix4x4.TRS(
                Vector3.zero,
                Quaternion.identity,
                new Vector3(
                    1.0f / transform.localScale.x,
                    1.0f / transform.localScale.y,
                    1.0f / transform.localScale.z));

            var invPivot = Matrix4x4.TRS(-Pivot, Quaternion.identity, Vector3.one);  // inv Pivot

            var invMatrix = s * r * t * invPivot;

            var parent = GetParentSceneNode();
            if (parent == null)
            {
                return invMatrix;
            }
            else
            {
                return invMatrix * parent.GetInverseMatrix();
            }
        }

        public void CompositeXform(ref Matrix4x4 parentXform)
        {
            Matrix4x4 pivot = Matrix4x4.TRS(Pivot, Quaternion.identity, Vector3.one);  // Pivot translation
            Matrix4x4 invPivot = Matrix4x4.TRS(-Pivot, Quaternion.identity, Vector3.one);  // inv Pivot
            Matrix4x4 trs = Matrix4x4.TRS(transform.localPosition, transform.localRotation, transform.localScale);

            mCombinedParentXform = parentXform * pivot * trs;

            // propagate to all children
            foreach (Transform child in transform)
            {
                SceneNode cn = child.GetComponent<SceneNode>();
                if (cn != null)
                {
                    cn.CompositeXform(ref mCombinedParentXform);
                }
            }

            // disenminate to primitives
            foreach (NodePrimitive p in PrimitiveList)
            {
                p.LoadShaderMatrix(ref mCombinedParentXform);
            }
        }

        /// <summary>
        /// Gets the child scene nodes for this scene node.
        /// </summary>
        /// <returns>The children.</returns>
        public List<SceneNode> GetChildren()
        {
            var children = new List<SceneNode>();
            var xform = this.transform;
            for (int i = 0; i < xform.childCount; i++)
            {
                var obj = xform.GetChild(i).gameObject;
                var childNode = obj.GetComponent<SceneNode>();
                if (childNode != null)
                {
                    children.Add(childNode);
                }
            }
            return children;
        }

        /// <summary>
        /// Adds node primitives from the "geom" game object container.
        /// </summary>
        private void AddPrimitives()
        {
            if (_primitiveList == null)
            {
                var geomContainer = GetGeometryContainer();
                if (geomContainer != null)
                {
                    _primitiveList = geomContainer
                        .GetComponentsInChildren<NodePrimitive>()
                        .ToList();
                }
                else
                {
                    _primitiveList = new List<NodePrimitive>();
                }
            }
        }

        /// <summary>
        /// Gets the game object container for primitives.
        /// </summary>
        /// <returns>The geometry container.</returns>
        private GameObject GetGeometryContainer()
        {
            for (int i = 0; i < transform.childCount; i++)
            {
                var obj = transform.GetChild(i).gameObject;
                if (obj.name == "geom")
                {
                    return obj;
                }
            }
            return null;
        }
        
        /// <summary>
        ///     Visits all nodes recursively.
        /// </summary>
        public void Visit(Action<Node> visitor)
        {
            // visit self.
            visitor(this);

            // visit primitives.
            if (PrimitiveList != null)
            {
                PrimitiveList.ForEach(np => visitor(np));
            }

            // visit child scene nodes.
            GetChildren().ForEach(sn => sn.Visit(visitor));
        }

        /// <summary>
        ///     Returns all child nodes recursively.
        /// </summary>
        public List<Node> Descendants()
        {
            var nodes = new List<Node>();
            Visit(n => nodes.Add(n));
            return nodes;
        }

        /// <summary>
        ///     Gets and sets the world position of a SceneNode.
        /// </summary>
        public override Vector3 WorldPosition
        {
            set
            {
                var parent = GetParentSceneNode();
                var invM = (parent == null) ? Matrix4x4.identity : parent.GetInverseMatrix();
                var m = (parent == null) ? Matrix4x4.identity : parent.GetMatrix();
                
                var localPos = invM.MultiplyPoint(value) - this.Pivot;
                transform.localPosition = localPos;

                // Force a recomputation of the matrix.
                CompositeXform(ref m);
            }
            get
            {
                return GetMatrix().GetPosition();
            }
        }
    }
}