﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;
using Logger = Util.Logger;

namespace Model
{
    public class SelectableNodeState : MonoBehaviour
    {
        private Color? _previousColor = null;
        private Material[] _previousMaterials;

        public void Select(Color selectedColor, Material selectedMaterial)
        {
            if (Is451Shaded())
            {
                var np = gameObject.GetComponent<NodePrimitive>();
                if (!_previousColor.HasValue)
                    _previousColor = np.MyColor;
                np.MyColor = selectedColor;
            }
            else
            {
                var rend = gameObject.GetComponent<Renderer>();
                if (_previousMaterials == null)
                    _previousMaterials = rend.materials;
                rend.materials = ManyMaterials(selectedMaterial, rend.materials.Length);
            }
        }
        
        public void UnSelect()
        {
            if (Is451Shaded())
            {
                var np = gameObject.GetComponent<NodePrimitive>();
                if (_previousColor.HasValue)
                {
                    np.MyColor = _previousColor.Value;
                    _previousColor = null;
                }
            }
            else
                gameObject.GetComponent<Renderer>().materials = _previousMaterials;
        }
        
        public static SelectableNodeState Get(NodePrimitive np)
        {
            var sns = np.gameObject.GetComponent<SelectableNodeState>();
            if (sns == null)
            {
                sns = np.gameObject.AddComponent<SelectableNodeState>();
            }
            return sns;
        }

        private bool Is451Shaded()
        {
            var rend = gameObject.GetComponent<Renderer>();
            return rend != null && rend.material.shader.name.Equals("Unlit/451Shader");
        }

        private Material[] ManyMaterials(Material material, int count)
        {
            var m = new Material[count];
            for (var i = 0; i < count; i++)
                m[i] = material;
            return m;
        }
    }
}
