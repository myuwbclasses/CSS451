﻿using System;
using System.Globalization;

// ReSharper disable CheckNamespace
// ReSharper disable UseNameofExpression
// ReSharper disable ArrangeAccessorOwnerBody

/// <summary>
///     A timecode
/// </summary>
public class Timecode
{
    /// <summary>
    ///     Internal time
    /// </summary>
    private double _time;

    /// <summary>
    ///     Create a new Timecode at 00.00
    /// </summary>
    public Timecode()
    {
    }

    /// <summary>
    ///     Create a new Timecode at the given time
    /// </summary>
    /// <param name="time">Time to set</param>
    public Timecode(double time)
    {
        Time = time;
    }

    /// <summary>
    ///     Create a new Timecode at the time of a given Timecode
    /// </summary>
    /// <param name="timecode">Timecode to copy</param>
    /// <exception cref="ArgumentNullException">Given Timecode is null</exception>
    public Timecode(Timecode timecode)
    {
        if (ReferenceEquals(null, timecode))
            throw new ArgumentNullException("timecode",
                "Cannot copy from null Timecode");
        Time = timecode.Time;
    }

    /// <summary>
    ///     The time of this timecode in ss.ff
    /// </summary>
    /// <exception cref="ArgumentOutOfRangeException">Given time is less than zero</exception>
    public double Time
    {
        get { return _time; }
        set
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException("value",
                    "Timecode cannot be less than zero");
            _time = Math.Round(value, 2);
        }
    }

    /// <summary>
    ///     Get Time as a float
    /// </summary>
    public float FTime
    {
        get { return (float) Time; }
    }

    /// <summary>
    ///     Compare this Timecode to another
    /// </summary>
    /// <param name="other">Timecode to compare</param>
    /// <returns>Timecodes equal</returns>
    public bool Equals(Timecode other)
    {
        return _time.Equals(other._time);
    }

    /// <summary>
    ///     Compare this Timecode to an object
    /// </summary>
    /// <param name="obj">Object to compare</param>
    /// <returns>Timecode and object are equal</returns>
    public override bool Equals(object obj)
    {
        if (ReferenceEquals(null, obj)) return false;
        return obj.GetType() == typeof(Timecode) && obj.Equals(this);
    }

    /// <summary>
    ///     Get hash code of this Timecode
    /// </summary>
    /// <returns>Hash code</returns>
    public override int GetHashCode()
    {
        return _time.GetHashCode();
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs &lt; rhs</returns>
    public static bool operator <(Timecode lhs, Timecode rhs)
    {
        return lhs.Time < rhs.Time;
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs &gt; rhs</returns>
    public static bool operator >(Timecode lhs, Timecode rhs)
    {
        return lhs.Time > rhs.Time;
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs equals rhs</returns>
    public static bool operator ==(Timecode lhs, Timecode rhs)
    {
        return !ReferenceEquals(null, lhs) && lhs.Equals(rhs);
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs does not equal rhs</returns>
    public static bool operator !=(Timecode lhs, Timecode rhs)
    {
        return !(lhs == rhs);
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs less or equal rhs</returns>
    public static bool operator <=(Timecode lhs, Timecode rhs)
    {
        return lhs < rhs || lhs == rhs;
    }

    /// <summary>
    ///     Compare two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs greater or equal rhs</returns>
    public static bool operator >=(Timecode lhs, Timecode rhs)
    {
        return lhs > rhs || lhs == rhs;
    }

    /// <summary>
    ///     Add two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>Sum of lhs and rhs</returns>
    public static Timecode operator +(Timecode lhs, Timecode rhs)
    {
        return new Timecode(lhs.Time + rhs.Time);
    }

    /// <summary>
    ///     Add a double and Timecode
    /// </summary>
    /// <param name="lhs">Timecode</param>
    /// <param name="rhs">double</param>
    /// <returns>Sum of lhs and rhs</returns>
    public static Timecode operator +(Timecode lhs, double rhs)
    {
        return new Timecode(lhs.Time + rhs);
    }

    /// <summary>
    ///     Subtract two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>Difference of lhs and rhs</returns>
    public static Timecode operator -(Timecode lhs, Timecode rhs)
    {
        return new Timecode(lhs.Time - rhs.Time);
    }

    /// <summary>
    ///     Divide two Timecodes
    /// </summary>
    /// <param name="lhs"></param>
    /// <param name="rhs"></param>
    /// <returns>lhs over rhs</returns>
    public static Timecode operator /(Timecode lhs, Timecode rhs)
    {
        return new Timecode(lhs.Time / rhs.Time);
    }

    /// <summary>
    ///     Represent this Timecode in a string
    /// </summary>
    /// <returns>String representation</returns>
    public override string ToString()
    {
        var floor = (int)Math.Floor(Time);
        return string.Format("{0}:{1:D2}", floor, (int) ((Time - floor) * 100));
    }
}