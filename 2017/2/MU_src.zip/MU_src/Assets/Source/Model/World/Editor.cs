﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Model;
using Util;

namespace Model.World
{
    /// <summary>
    /// The main model for the editor.
    /// </summary>
    public class Editor : MonoBehaviour
    {
        /// <summary>
        /// The mode that the editor is in.
        /// (Using a watchable attribute will allow other components to take action on mode change.)
        /// </summary>
        public readonly WatchableAttribute<EditorMode> Mode = new WatchableAttribute<EditorMode>(EditorMode.Edit);

        /// <summary>
        /// Helper to call a method when the mode switches.
        /// </summary>
        /// <param name="editModeAction">Edit mode action.</param>
        /// <param name="playModeAction">Play mode action.</param>
        public void WatchMode(Action editModeAction, Action playModeAction)
        {
            Action<EditorMode, EditorMode> handler = (newMode, mode) =>
            {
                switch (mode)
                {
                    case EditorMode.Play:
                        playModeAction();
                        break;
                    case EditorMode.Edit:
                        editModeAction();
                        break;
                }
            };

            // Setup a listener for editor mode changes.
            Mode.AddListener(handler);

            // Also invoke method based on the current setting.
            handler(Mode.Value, Mode.Value);
        }
    }
}