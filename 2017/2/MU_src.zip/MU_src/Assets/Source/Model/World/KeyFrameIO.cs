﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using UnityEngine;
using LightJson;
using LightJson.Serialization;

namespace Model.World
{
    /// <summary>
    ///     Helper for saving and loading key frames.
    /// </summary>
    public class KeyFrameIO
    {
        public ManipulableObjects ManipulableObjects;

        public KeyFrameIO(ManipulableObjects manipulableObjects)
        {
            ManipulableObjects = manipulableObjects;
        }

        public IEnumerable<Keyframe> Load(string filePath)
        {
            using (var reader = new StreamReader(File.OpenRead(filePath), true))
            {
                var jsonObj = JsonReader.Parse(reader);
                return ToKeyframes(jsonObj);
            }
        }

        public IEnumerable<Keyframe> ToKeyframes(JsonObject obj)
        {
            return obj["keyframes"].AsJsonArray.Select(entry => ToKeyFrame( entry.AsJsonObject));
        }

        private Keyframe ToKeyFrame(JsonObject obj)
        {
            var timecode = obj["timecode"].AsNumber;
            var kf = new Keyframe(new Timecode(timecode));
            foreach (var entry in obj["transforms"].AsJsonArray)
            {
                kf.KeyframeTransforms.Add(ToKeyFrameTransform(entry.AsJsonObject));
            }
            return kf;
        }

        private Keyframe.KeyframeTransform ToKeyFrameTransform(JsonObject obj)
        {
            var id = obj["id"].AsInteger;
            var translation = obj["translation"].AsJsonArray;
            var up = obj["up"].AsJsonArray;

            return new Keyframe.KeyframeTransform(
                ManipulableObjects.Get(id),
                new Vector3(
                    (float)translation[0].AsNumber,
                    (float)translation[1].AsNumber,
                    (float)translation[2].AsNumber),
                new Quaternion(
                    (float)up[0].AsNumber,
                    (float)up[1].AsNumber,
                    (float)up[2].AsNumber,
                    (float)up[3].AsNumber));
        }

        public void Save(string filePath, IEnumerable<Keyframe> keyFrames)
        {
            var doc = ToJson(keyFrames);
            using (var output = new StreamWriter(File.OpenWrite(filePath), Encoding.UTF8))
            {
                output.Write(doc.ToString(true));
            }
        }

        private JsonObject ToJson(IEnumerable<Keyframe> keyFrames)
        {
            var doc = new JsonObject();
            var jKeyFrames = new JsonArray();
            foreach (var kf in keyFrames)
            {
                jKeyFrames.Add(ToJson(kf));
            }
            doc.Add("keyframes", jKeyFrames);
            return doc;
        }

        private JsonObject ToJson(Keyframe kf)
        {
            var obj = new JsonObject();
            obj.Add("timecode", kf.TheTimecode.FTime);
            var xforms = new JsonArray();
            foreach (var xform in kf.KeyframeTransforms)
            {
                xforms.Add(ToJson(xform));
            }
            obj.Add("transforms", xforms);
            return obj;
        }

        private JsonObject ToJson(Keyframe.KeyframeTransform xform)
        {
            var obj = new JsonObject();
            obj.Add("id", ManipulableObjects.GetId(xform.TheGameObject));
            obj.Add("name", xform.TheGameObject.name);
            obj.Add("translation", ToJson(xform.Translation));
            obj.Add("up", ToJson(xform.Up));
            return obj;
        }

        private JsonArray ToJson(Vector3 v)
        {
            var array = new JsonArray();
            array.Add(v.x);
            array.Add(v.y);
            array.Add(v.z);
            return array;
        }

        private JsonArray ToJson(Quaternion q)
        {
            var array = new JsonArray();
            array.Add(q.x);
            array.Add(q.y);
            array.Add(q.z);
            array.Add(q.w);
            return array;
        }
    }
}
