﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Util;
using UnityEngine;

namespace Model.World
{
    /// <summary>
    /// Determines which object can be manipulated.
    /// </summary>
    public class ManipulableObjects : MonoBehaviour
    {
        public SceneNodes SceneNodes;
        public Camera PlayCamera;

        /// <summary>
        /// Used to fire and listen for events when a game object is changed in some meaningful way.
        /// </summary>
        public readonly ApplicationEvent<GameObject> GameObjectChangeEvent = new ApplicationEvent<GameObject>();

        private List<GameObject> _gameObjects = null;

        public List<GameObject> GameObjects
        {
            get
            {
                if (_gameObjects == null)
                {
                    _gameObjects = new List<GameObject>();
                    foreach (var node in SceneNodes.Root.Descendants())
                    {
                        _gameObjects.Add(node.gameObject);
                    }
                    _gameObjects.Add(PlayCamera.gameObject);

                    _objectToIdMap = new Dictionary<GameObject, int>();
                    for (var i = 0; i < _gameObjects.Count; i++)
                    {
                        _objectToIdMap[_gameObjects[i]] = i;
                    }
                }
                return _gameObjects;
            }
        }

        private Dictionary<GameObject, int> _objectToIdMap;

        void Start()
        {
            // Force trigger.
            var go = GameObjects;
        }

        public GameObject Get(int id)
        {
            return (id >= 0 && id < GameObjects.Count) ? GameObjects[id] : null;
        }

        public int GetId(GameObject obj)
        {
            return _objectToIdMap[obj];
        }
    }
}
