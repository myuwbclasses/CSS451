﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Model;
using Util;
using UnityEngine;

namespace Model.World
{
    public class ManipulationModes : MonoBehaviour
    {
        public WatchableAttribute<ManipulationMode> Current = new WatchableAttribute<ManipulationMode>(ManipulationMode.Position);

        // Toggles the manipulation mode.
        public void Toggle()
        {
            switch (Current.Value)
            {
                case ManipulationMode.Position:
                    Current.Value = ManipulationMode.Rotation;
                    return;
                case ManipulationMode.Rotation:
                    Current.Value = ManipulationMode.Position;
                    return;
            }
        }
    }
}
