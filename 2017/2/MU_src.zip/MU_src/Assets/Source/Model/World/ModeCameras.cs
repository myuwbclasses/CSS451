﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Model;
using Util;
using Logger = Util.Logger;

namespace Model.World
{
    /// <summary>
    /// Model for the 2 camera views.
    /// </summary>
    public class ModeCameras : MonoBehaviour
    {
        public Editor Editor;
        public Camera PlayCamera;
        public Camera EditCamera;

        private Rect mOriginalPlayCameraRect;

        void Start()
        {
            mOriginalPlayCameraRect = PlayCamera.rect;

            // When the editor changes modes,
            // update what cameras are displayed and how.
            Editor.WatchMode(OnEditMode, OnPlayMode);
        }

        private void OnPlayMode()
        {
            Logger.Debug("Entering play mode for cameras.");

            // Create a new rect suitable for play mode.
            var rect = PlayCamera.rect;
            rect.width = 1;
            rect.height = 1;
            PlayCamera.rect = rect;

            // Turn off the edit camera.
            // There is no need to waste time rendering it.
            EditCamera.gameObject.SetActive(false);
        }

        private void OnEditMode()
        {
            Logger.Debug("Entering edit mode for cameras.");
            PlayCamera.rect = mOriginalPlayCameraRect;

            // Turn on the edit camera.
            EditCamera.gameObject.SetActive(true);
        }
    }
}

