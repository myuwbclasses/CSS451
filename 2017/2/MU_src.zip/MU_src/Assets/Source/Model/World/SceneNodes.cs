﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

using Model;

namespace Model.World
{
    /// <summary>
    /// Container for the Root scene node.
    /// Also responsible for computing the shader matrix.
    /// </summary>
    public class SceneNodes : MonoBehaviour
    {
        public SceneNode Root;

        void Update()
        {
            UpdateMatrices();
        }

        public void UpdateMatrices()
        {
            if (Root != null)
            {
                Matrix4x4 i = Matrix4x4.identity;
                Root.CompositeXform(ref i);
            }
        }
    }
}