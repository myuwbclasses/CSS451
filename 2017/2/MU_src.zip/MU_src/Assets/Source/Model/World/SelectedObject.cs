﻿using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;
using Util;
using Logger = Util.Logger;

namespace Model.World
{
    public class SelectedObject : MonoBehaviour
    {
        public Color SelectedColor = Color.yellow;
        public Material SelectedMaterial;
        public Editor Editor;

        public readonly WatchableAttribute<GameObject> Current = new WatchableAttribute<GameObject>(null);

        void Start()
        {
            Current.AddListener(OnSelectedObjectChange);
            Editor.WatchMode(OnEditMode, OnPlayMode);
        }

        private void OnEditMode()
        {
        }

        private void OnPlayMode()
        {
            Current.Value = null;
        }

        private void OnSelectedObjectChange(GameObject old, GameObject selected)
        {
            Logger.Debug("Selected object: {0}.", selected == null ? "none" : selected.name);
            UnSelect(old);
            Select(selected);
        }

        private void Select(GameObject obj)
        {
            ActOnDirectPrimitives(obj, p => SelectableNodeState.Get(p).Select(SelectedColor, SelectedMaterial));
        }

        private void UnSelect(GameObject obj)
        {
            ActOnDirectPrimitives(obj, p => SelectableNodeState.Get(p).UnSelect());
        }

        private void ActOnDirectPrimitives(GameObject obj, Action<NodePrimitive> action)
        {
            if (obj == null)
                return;

            var node = obj.GetComponent<Node>();
            if (node is SceneNode)
            {
                ((SceneNode)node).PrimitiveList.ForEach(action);
            }
            else if (node is NodePrimitive)
            {
                action((NodePrimitive)node);
            }
        }
    }
}

