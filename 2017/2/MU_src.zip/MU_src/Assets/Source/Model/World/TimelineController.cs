﻿using System;
using System.Collections.Generic;
using System.Linq;
using Model;
using Model.World;
using UnityEngine;
using UnityEngine.UI;

using Logger = Util.Logger;

// ReSharper disable UseNullPropagation
// ReSharper disable ArrangeAccessorOwnerBody
// ReSharper disable UseNameofExpression
// ReSharper disable CheckNamespace

public class TimelineController : MonoBehaviour
{
    /// <summary>
    ///     List of Keyframes on timeline
    /// </summary>
    private SortedDictionary<double, Keyframe> _keyframes = new SortedDictionary<double, Keyframe>();

    /// <summary>
    ///     The original key frames used for resetting.
    /// </summary>
    private SortedDictionary<double, Keyframe> _originalKeyFrames = null;

    /// <summary>
    ///     Current position on timeline
    /// </summary>
    private Timecode _currentTimecode;

    /// <summary>
    ///     The length of this timeline
    /// </summary>
    public Timecode Length = new Timecode(10.00);

    /// <summary>
    ///     If this timeline is playing
    /// </summary>
    private bool _playing;

    /// <summary>
    ///     The editor
    /// </summary>
    public Editor TheEditor;

    /// <summary>
    ///     Text used to display timecode
    /// </summary>
    public Text TimecodeDisplayText;

    /// <summary>
    ///     The objects that can be manipulated and should be saved.
    /// </summary>
    public ManipulableObjects ManipulableObjects;

    /// <summary>
    ///     Helper to save and load key frames.
    /// </summary>
    private KeyFrameIO _keyFrameIO;

    /// <summary>
    ///     SceneNode root
    /// </summary>
    public SceneNodes SceneNodes;

    /// <summary>
    ///     Current position on timeline
    /// </summary>
    public Timecode CurrentTimecode
    {
        get { return _currentTimecode; }
        set
        {
            if (value > Length)
                throw new TimelineElapsedException();

            _currentTimecode = value;
            OnCurrentTimecodeChange();
        }
    }

    /// <summary>
    ///     Fired when timeline completes playback
    /// </summary>
    public event EventHandler TimelineElapsed;

    protected virtual void OnTimelineElapsed(EventArgs eventArgs)
    {
        if (TimelineElapsed != null) TimelineElapsed(this, eventArgs);
    }

    public event EventHandler KeyframeModified;

    protected virtual void OnKeyframeModified(EventArgs eventArgs)
    {
        if (KeyframeModified != null) KeyframeModified(this, eventArgs);
    }

    /// <summary>
    ///     Start playback
    /// </summary>
    private void Play()
    {
        _playing = true;
    }

    /// <summary>
    ///     Stop playback
    /// </summary>
    private void Stop()
    {
        _playing = false;
    }

    /// <summary>
    ///     Initialization code
    /// </summary>
    private void Start()
    {
        // Create helper for io.
        _keyFrameIO = new KeyFrameIO(ManipulableObjects);

        // When an object is manipulated auto trigger key frame creation.
        ManipulableObjects.GameObjectChangeEvent.AddListener(OnGameObjectChanged);

        Length = new Timecode(10.00);
        CreateKeyframe(new Timecode(0));
        CurrentTimecode = new Timecode(0);

        TheEditor.WatchMode(Stop, Play);

        // Save the original key frames.
        _originalKeyFrames = new SortedDictionary<double, Keyframe>(_keyframes);
    }

    /// <summary>
    ///     Update code
    /// </summary>
    private void Update()
    {
        if (!_playing)
            return;

        try
        {
            CurrentTimecode += Time.deltaTime;
        }
        // End of timeline reached
        catch (TimelineElapsedException)
        {
            _playing = false;
            CurrentTimecode = new Timecode();
            TheEditor.Mode.Value = EditorMode.Edit;
        }
    }

    /// <summary>
    ///     When a GameObject is manipulated save the key frame.
    /// </summary>
    /// <param name="obj"></param>
    private void OnGameObjectChanged(GameObject obj)
    {
        Logger.Info("Creating a new keyframe on object change.");
        CreateKeyframe(_currentTimecode);
    }

    /// <summary>
    ///     Handle changes to CurrentTimecode
    /// </summary>
    private void OnCurrentTimecodeChange()
    {
        TimecodeDisplayText.text = CurrentTimecode.ToString();

        foreach (var keyframeTransform in GetKeyframe(CurrentTimecode).KeyframeTransforms)
        {
            var target = keyframeTransform.TheGameObject;
            target.transform.localPosition = keyframeTransform.Translation;
            target.transform.localRotation = keyframeTransform.Up;
        }
    }

    /// <summary>
    ///     Check if a keyframe exists at the given timecode
    /// </summary>
    /// <param name="timecode">Timecode to check</param>
    /// <returns>Keyframe exists at timecode</returns>
    public bool KeyframeExistsAt(Timecode timecode)
    {
        return _keyframes.ContainsKey(timecode.Time);
    }

    /// <summary>
    ///     Set the given Keyframe. If a keyframe is present at the given Keyframe's timecode, it will be overwritten.
    /// </summary>
    /// <param name="keyframe">Keyframe to set</param>
    /// <returns>Keyframe overwritten</returns>
    public bool SetKeyframe(Keyframe keyframe)
    {
        if (_playing)
            throw new InvalidOperationException(
                "Keyframes cannot be changed while playing");

        if (KeyframeExistsAt(keyframe.TheTimecode))
        {
            _keyframes[keyframe.TheTimecode.Time] = keyframe;
            OnKeyframeModified(EventArgs.Empty);
            return true;
        }

        _keyframes.Add(keyframe.TheTimecode.Time, keyframe);
        OnKeyframeModified(EventArgs.Empty);
        return false;
    }

    /// <summary>
    ///     Get the Keyframe with the given timecode
    /// </summary>
    /// <param name="timecode">Timecode of target Keyframe</param>
    /// <returns></returns>
    public Keyframe GetKeyframe(Timecode timecode)
    {
        if (_keyframes.Count == 0)
            throw new ArgumentOutOfRangeException("timecode", "No keyframes present");

        // Return exact keyframe if it exists, interpolate otherwise
        if (KeyframeExistsAt(timecode))
            return _keyframes[timecode.Time];
        
        var before = _keyframes.Values.LastOrDefault(k => k.TheTimecode < timecode);
        var after = _keyframes.Values.FirstOrDefault(k => k.TheTimecode > timecode);

        if (before == null)
            throw new ArgumentOutOfRangeException("timecode", "Given timecode not bounded by keyframes");

        // If there is no keyframe stored after this point, use the previous key frame.
        if (after == null)
            return before;

        return Keyframe.Interpolate(before, after, timecode);
    }

    /// <summary>
    ///     Remove the keyframe with the given timecode
    /// </summary>
    /// <param name="timecode">Timecode of Keyframe to remove</param>
    public void RemoveKeyframe(Timecode timecode)
    {
        if (_playing)
            throw new InvalidOperationException(
                "Keyframes cannot be changed while playing");

        // Do not allow removal of keyframe 0
        if (timecode == new Timecode(0))
        {
            _keyframes[0] = new Keyframe(new Timecode(0));
            return;
        }

        _keyframes.Remove(timecode.Time);
        OnKeyframeModified(EventArgs.Empty);
    }

    /// <summary>
    ///     Creates a new key frame from the current game object state for the given timecode.
    /// </summary>
    /// <param name="timecode"></param>
    public void CreateKeyframe(Timecode timecode)
    {
        var newKeyframe = new Keyframe(timecode);

        foreach (var obj in ManipulableObjects.GameObjects)
            newKeyframe.KeyframeTransforms.Add(
                new Keyframe.KeyframeTransform(
                    obj.gameObject,
                    obj.transform.localPosition,
                    obj.transform.localRotation));

        SetKeyframe(newKeyframe);
    }

    /// <summary>
    ///     Get a list of the keyframe timecodes
    /// </summary>
    /// <returns>List of timecodes</returns>
    public List<Timecode> ListKeyframeTimecodes()
    {
        return _keyframes.Values.Select(keyframe => new Timecode(keyframe.TheTimecode)).ToList();
    }

    /// <summary>
    ///     Saves the timeline to a file.
    /// </summary>
    /// <param name="filePath"></param>
    public void Save(string filePath)
    {
        _keyFrameIO.Save(filePath, _keyframes.Values);
    }

    /// <summary>
    ///     Loads key frames from file.
    /// </summary>
    /// <param name="filePath"></param>
    public void Load(string filePath)
    {
        Stop();
        var keyframes = _keyFrameIO.Load(filePath);
        _keyframes.Clear();
        foreach (var kf in keyframes)
        {
            _keyframes[kf.TheTimecode.Time] = kf;
        }
        CurrentTimecode = new Timecode(0);
        OnKeyframeModified(EventArgs.Empty);
    }

    /// <summary>
    ///     Clears out key frames and resets objects to their original position
    /// </summary>
    public void Reset()
    {
        Stop();
        _keyframes = new SortedDictionary<double, Keyframe>(_originalKeyFrames);
        Length = new Timecode(10.00);
        CurrentTimecode = new Timecode(0);
        OnKeyframeModified(EventArgs.Empty);
    }

    /// <inheritdoc />
    /// <summary>
    ///     Exception thrown when timeline elapses
    /// </summary>
    public class TimelineElapsedException : Exception
    {
        public new readonly string Message = "Current Timecode cannot be set past timeline length";
    }
}