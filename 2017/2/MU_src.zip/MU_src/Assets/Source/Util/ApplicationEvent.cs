﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Util
{
    /// <summary>
    /// Handles firing and listening to and for events of a given type.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApplicationEvent<T>
    {
        private List<Action<T>> mListeners = new List<Action<T>>();

        public void AddListener(Action<T> listener)
        {
            mListeners.Add(listener);
        }

        public void RemoveListener(Action<T> listener)
        {
            mListeners.Remove(listener);
        }

        public void Fire(T e)
        {
            foreach (var listener in mListeners)
            {
                listener(e);
            }
        }
    }

    /// <summary>
    /// An event with no arguments.
    /// </summary>
    public class ApplicationEvent
    {
        private List<Action> mListeners = new List<Action>();

        public void AddListener(Action listener)
        {
            mListeners.Add(listener);
        }

        public void RemoveListener(Action listener)
        {
            mListeners.Remove(listener);
        }

        public void Fire()
        {
            foreach (var listener in mListeners)
            {
                listener();
            }
        }
    }
}
