﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

using Logger = Util.Logger;

namespace Util.Collide
{
    public class MeshObjectColliderInternal
    {
        public Vertices Vertices { get; private set; }

        public Vector3 Center { get; private set; }
        public float Radius { get; private set; }

        private int _maxComplexity;
        private Vector3 _lowerBounds;
        private Vector3 _upperBounds;
        private List<Triangle> _triangles = null;
        private HashSet<int> _wantedVertices = null;
        private List<MeshObjectColliderInternal> _childColliders = null;

        public static MeshObjectColliderInternal Create(
            Vertices vertices,
            IEnumerable<int> checkVertices,
            Vector3 lowerBounds,
            Vector3 upperBounds,
            int maxComplexity)
        {
            return new MeshObjectColliderInternal(vertices, checkVertices, lowerBounds, upperBounds, maxComplexity).SimplifyStructure();
        }

        public MeshObjectColliderInternal(
            Vertices vertices,
            IEnumerable<int> checkVertices,
            Vector3 lowerBounds,
            Vector3 upperBounds,
            int maxComplexity)
        {
            Vertices = vertices;
            _upperBounds = upperBounds;
            _lowerBounds = lowerBounds;
            _maxComplexity = maxComplexity;

            InitializeVertexData(checkVertices, lowerBounds, upperBounds);
            InitializeChildren();
        }

        public MeshObjectColliderInternal SimplifyStructure()
        {
            if (_childColliders != null && _childColliders.Count() == 1)
            {
                return _childColliders[0];
            }
            return this;
        }

        public string ShowStructure()
        {
            var sb = new StringBuilder();
            ShowStructure(sb, 0);
            return sb.ToString();
        }

        private void ShowStructure(StringBuilder sb, int depth)
        {
            for (int i = 0; i < depth; i++)
            {
                sb.Append("  ");
            }
            sb.Append(string.Format("Collider: triangles={0} Center={1} Radius={2}\n", _triangles.Count, Center, Radius));
            if (_childColliders != null)
            {
                foreach (var cc in _childColliders)
                {
                    cc.ShowStructure(sb, depth + 1);
                }
            }
        }

        public bool IsNeeded()
        {
            return (_triangles != null && _triangles.Count > 0);
        }

        public bool CollidesWith(
            MeshObjectColliderInternal other,
            Matrix4x4 otherMatrix,
            Matrix4x4 invMatrix)
        {
            var otherToLocalMatrix = invMatrix * otherMatrix;
            var scale = otherToLocalMatrix.GetScale();
            var maxScale = Mathf.Max(scale.x, scale.y, scale.z);

            var collisionCache = new bool[this._triangles.Count * other._triangles.Count];

            return CollidesWith(other, otherToLocalMatrix, maxScale, collisionCache);
        }

        internal bool CollidesWith(
            MeshObjectColliderInternal other,
            Matrix4x4 otherToLocalMatrix,
            float maxScale,
            bool[] collisionCache)
        {
            var oCenter = otherToLocalMatrix.MultiplyPoint(other.Center);
            var d = (oCenter - Center).magnitude;
            var otherReach = other.Radius * maxScale;
            var cRadius = Radius + otherReach;

            if (d <= cRadius)
            {
                if (this._childColliders != null && other._childColliders == null)
                {
                    return CollidesWithThisChildren(other, otherToLocalMatrix, maxScale, collisionCache);
                }
                else if (this._childColliders == null && other._childColliders != null)
                {
                    return CollidesWithOtherChildren(other, otherToLocalMatrix, maxScale, collisionCache);
                }
                else if (this._childColliders == null && other._childColliders == null)
                {
                    return true;
                    // Triangle checking is too slow and not accurate.
                    //return CollidesWithTriangles(other, otherToLocalMatrix, maxScale, collisionCache);
                }
                else if (otherReach > Radius)
                {
                    return CollidesWithOtherChildren(other, otherToLocalMatrix, maxScale, collisionCache);
                }
                else
                {
                    return CollidesWithThisChildren(other, otherToLocalMatrix, maxScale, collisionCache);
                }
            }

            return false;
        }

        internal bool CollidesWithThisChildren(
            MeshObjectColliderInternal other,
            Matrix4x4 otherToLocalMatrix,
            float maxScale,
            bool[] collisionCache)
        {
            foreach (var child in this._childColliders)
            {
                if (child.CollidesWith(other, otherToLocalMatrix, maxScale, collisionCache))
                {
                    return true;
                }
            }
            return false;
        }

        internal bool CollidesWithOtherChildren(
            MeshObjectColliderInternal other,
            Matrix4x4 otherToLocalMatrix,
            float maxScale,
            bool[] collisionCache)
        {
            foreach (var oChild in other._childColliders)
            {
                if (this.CollidesWith(oChild, otherToLocalMatrix, maxScale, collisionCache))
                {
                    return true;
                }
            }
            return false;
        }

        internal bool CollidesWithTriangles(
            MeshObjectColliderInternal other,
            Matrix4x4 otherToLocalMatrix,
            float maxScale,
            bool[] collisionCache)
        {
            //Logger.Info("triangle check: {0} {1}", _triangles.Count, other._triangles.Count);

            var otherTriangles = other._triangles.Select(t =>
            {
                return new Vector3[] {
                    otherToLocalMatrix.MultiplyPoint(other.Vertices.Data[t.A]),
                    otherToLocalMatrix.MultiplyPoint(other.Vertices.Data[t.B]),
                    otherToLocalMatrix.MultiplyPoint(other.Vertices.Data[t.C])
                };
            }).ToArray();

            foreach (var t in this._triangles)
            {
                for (var oti = 0; oti < otherTriangles.Length; oti++)
                {
                    var ot = otherTriangles[oti];
                    var cck = t.Id + oti * this._triangles.Count;
                    if (!collisionCache[cck])
                    {
                        collisionCache[cck] = true;
                        if (Intersect.TriangleToTriangle(
                            Vertices.Data[t.A],
                            Vertices.Data[t.B],
                            Vertices.Data[t.C],
                            ot[0],
                            ot[1],
                            ot[2]))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        public Vector3? Raycast(Ray ray)
        {
            return Raycast(ray, new HashSet<int>());
        }

        public Vector3? Raycast(Ray ray, HashSet<int> visitedTriangles)
        {
            var p = Intersect.ClosestPointFromRayToPoint(Center, ray.origin, ray.direction);
            var d = (p - Center).magnitude;
            if (d > Radius)
            {
                return null;
            }

            // Get any hits.
            List<Vector3> hits = null;
            if (_childColliders != null)
            {
                hits = RaycastChildren(ray, visitedTriangles);
            }
            else
            {
                hits = RaycastTriangles(ray, visitedTriangles);
            }

            // Find the closes hit.
            float minD = float.MaxValue;
            Vector3? closestHit = null;
            foreach (var hit in hits)
            {
                var hitD = (hit - ray.origin).magnitude;
                if (hitD < minD)
                {
                    minD = hitD;
                    closestHit = hit;
                }
            }

            return closestHit;
        }

        private List<Vector3> RaycastTriangles(Ray ray, HashSet<int> visitedTriangles)
        {
            List<Vector3> hits = new List<Vector3>();
            foreach (var t in _triangles)
            {
                if (!visitedTriangles.Contains(t.Id))
                {
                    visitedTriangles.Add(t.Id);
                    var hit = Intersect.RayToTriangle(ray.origin, ray.direction, Vertices.Data[t.A], Vertices.Data[t.B], Vertices.Data[t.C]);
                    if (hit.HasValue)
                    {
                        hits.Add(hit.Value);
                    }
                }
            }
            return hits;
        }

        private List<Vector3> RaycastChildren(Ray ray, HashSet<int> visitedTriangles)
        {
            List<Vector3> hits = new List<Vector3>();
            foreach (var cCollider in _childColliders)
            {
                var hit = cCollider.Raycast(ray, visitedTriangles);
                if (hit.HasValue)
                {
                    hits.Add(hit.Value);
                }
            }
            return hits;
        }

        private void InitializeChildren()
        {
            int division = 2;
            var deltas = (_upperBounds - _lowerBounds) / ((float) division);

            // No need for children if there are few triangles.
            if (_triangles.Count <= _maxComplexity)
            {
                return;
            }

            // Don't create children for small boundaries.
            if ((_upperBounds - _lowerBounds).magnitude < 0.05)
            {
                return;
            }

            var childColliders = new List<MeshObjectColliderInternal>();
            bool significantReduction = false;

            // Build up the child colliders
            for (int xIdx = 0; xIdx < division; xIdx++)
            {
                var xStart = _lowerBounds.x + (deltas.x * xIdx);
                var xEnd = _lowerBounds.x + (deltas.x * (xIdx + 1));
                for (int yIdx = 0; yIdx < division; yIdx++)
                {
                    var yStart = _lowerBounds.y + (deltas.y * yIdx);
                    var yEnd = _lowerBounds.y + (deltas.y * (yIdx + 1));
                    for (int zIdx = 0; zIdx < division; zIdx++)
                    {
                        var zStart = _lowerBounds.z + (deltas.z * zIdx);
                        var zEnd = _lowerBounds.z + (deltas.z * (zIdx + 1));

                        var childCollider = Create(
                            Vertices,
                            _wantedVertices,
                            new Vector3(xStart, yStart, zStart),
                            new Vector3(xEnd, yEnd, zEnd),
                            _maxComplexity);

                        if (childCollider.IsNeeded())
                        {
                            childColliders.Add(childCollider);
                            var spaceReduction = 1.0f - ((float)childCollider._triangles.Count) / ((float)_triangles.Count);
                            if (spaceReduction >= 0.333f)
                            {
                                significantReduction = true;
                            }
                        }
                    }
                }
            }

            // There is enough of a reduction to use children.
            if (significantReduction)
            {
                _childColliders = childColliders;
            }
        }

        private void InitializeVertexData(IEnumerable<int> checkVertices, Vector3 lowerBounds, Vector3 upperBounds)
        {
            // Run through vertices.
            _wantedVertices = new HashSet<int>();
            foreach (var i in checkVertices)
            {
                // There is a bug here.
                // A triangle could intersect the boundary without being in the box.
                var v = Vertices.Data[i];
                if (v.x >= lowerBounds.x && v.x <= upperBounds.x &&
                    v.y >= lowerBounds.y && v.y <= upperBounds.y &&
                    v.z >= lowerBounds.z && v.z <= upperBounds.z)
                {
                    foreach (var tvi in Vertices.TriangleIndex[v])
                    {
                        _wantedVertices.Add(tvi.A);
                        _wantedVertices.Add(tvi.B);
                        _wantedVertices.Add(tvi.C);
                    }
                }
            }

            // Get the max radius
            Radius = 0.0f;
            foreach (var vi in _wantedVertices)
            {
                var ld = (Vertices.Data[vi] - Center).magnitude;
                if (ld > Radius)
                {
                    Radius = ld;
                }
            }
            
            _triangles = new List<Triangle>();
            var seen = new HashSet<int>();
            foreach (var vi in _wantedVertices)
            {
                foreach (var t in Vertices.TriangleIndex[Vertices.Data[vi]])
                {
                    if (!seen.Contains(t.Id))
                    {
                        _triangles.Add(t);
                        seen.Add(t.Id);
                    }
                }
            }
        }
    }
}
