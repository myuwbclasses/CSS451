﻿using Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

using UnityEngine;
using Logger = Util.Logger;

namespace Util.Collide
{
    public class MeshObjectCollider : MonoBehaviour
    {
        internal MeshObjectColliderInternal InternalCollider;
        
        public bool CollidesWith(MeshObjectCollider oCollider)
        {
            var sw = new Stopwatch();
            sw.Start();
            try
            {
                Node node = gameObject.GetComponent<Node>();
                Node oNode = oCollider.gameObject.GetComponent<Node>();

                var matrix = oNode.GetMatrix();
                var invMatrix = node.GetInverseMatrix();

                return InternalCollider.CollidesWith(oCollider.InternalCollider, matrix, invMatrix);
            }
            finally
            {
                var tms = sw.Elapsed.TotalMilliseconds;
                if (tms >= 40.0f)
                {
                    Logger.Info("CollidesWith: took {0} ms.", sw.Elapsed.TotalMilliseconds);
                }
            }
        }

        public Vector3? Raycast(Ray ray)
        {
            var node = gameObject.GetComponent<Node>();
            if (node != null)
            {
                var iMatrix = node.GetInverseMatrix();
                var matrix = node.GetMatrix();
                var localRayOrigin = iMatrix.MultiplyPoint(ray.origin);
                var localRayPoint = iMatrix.MultiplyPoint(ray.origin + ray.direction);
                var localRayVector = (localRayPoint - localRayOrigin).normalized;
                
                var localHit = InternalCollider.Raycast(new Ray(localRayOrigin, localRayVector));
                if (localHit.HasValue)
                {
                    return matrix.MultiplyPoint(localHit.Value);
                }
            }
            
            // TODO: Should I implement this for normal game object?
            return null;
        }

        public static MeshObjectCollider Get(GameObject obj)
        {
            var entry = obj.GetComponent<MeshObjectCollider>();
            if (entry == null)
            {
                entry = obj.AddComponent<MeshObjectCollider>();
                var vertices = new Vertices(obj);
                entry.InternalCollider = new MeshObjectColliderInternal(
                    vertices,
                    Enumerable.Range(0, vertices.Data.Length),
                    vertices.Minimums,
                    vertices.Maximums,
                    8);

                //Logger.Info("Built collider for {0}", obj.name);
                //Logger.Info(entry.InternalCollider.ShowStructure());
            }
            return entry;
        }
    }
}
