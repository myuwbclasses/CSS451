﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Util.Collide
{
    public class Triangle
    {
        public int Id { get; private set; }
        public Vertices Vertices { get; private set; }
        public int A { get; private set; }
        public int B { get; private set; }
        public int C { get; private set; }

        public Triangle(int id, Vertices vertices, int a, int b, int c)
        {
            Id = id;
            Vertices = vertices;
            A = a;
            B = b;
            C = c;
        }
    }
}
