﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Util.Collide
{
    public class Vertices
    {
        public Vector3[] Data { get; private set; }
        public Triangle[] Triangles { get; private set; }
        public IDictionary<Vector3, List<Triangle>> TriangleIndex = new Dictionary<Vector3, List<Triangle>>();

        public Vector3 Minimums { get; private set; }
        public Vector3 Maximums { get; private set; }

        public Vertices(GameObject obj)
        {
            var mesh = obj.GetComponent<MeshFilter>().mesh;
            Initialize(mesh.vertices, mesh.triangles);
            Logger.Info("new Vertices: Minimums={0} Maximums={1} obj={2}", Minimums, Maximums, obj.gameObject.name);
        }

        public Vertices(Vector3[] data, int[] triangles)
        {
            Initialize(data, triangles);
        }

        private void Initialize(Vector3[] data, int[] triangles)
        {
            Logger.Info("Initialize: {0} {1}", data.Length, triangles.Length);
            Data = data;
            InitializeTriangles(triangles);
            InitializeBoundaries();
        }

        private void InitializeTriangles(int[] triangles)
        {
            // Setup triangle data
            Triangles = new Triangle[triangles.Length / 3];
            List<Triangle> tList = null;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                var tid = i / 3;
                var v1 = Data[triangles[i]];
                var v2 = Data[triangles[i + 1]];
                var v3 = Data[triangles[i + 2]];
                var t = new Triangle(i / 3, this, triangles[i], triangles[i + 1], triangles[i + 2]);
                Triangles[t.Id] = t;

                if (!TriangleIndex.TryGetValue(v1, out tList))
                {
                    TriangleIndex[v1] = tList = new List<Triangle>();
                }
                tList.Add(t);

                if (!TriangleIndex.TryGetValue(v2, out tList))
                {
                    TriangleIndex[v2] = tList = new List<Triangle>();
                }
                tList.Add(t);

                if (!TriangleIndex.TryGetValue(v3, out tList))
                {
                    TriangleIndex[v3] = tList = new List<Triangle>();
                }
                tList.Add(t);
            }
        }

        private void InitializeBoundaries()
        {
            float minX = Data[0].x, maxX = Data[0].x;
            float minY = Data[0].y, maxY = Data[0].y;
            float minZ = Data[0].z, maxZ = Data[0].z;
            foreach (var v in Data)
            {
                if (v.x < minX)
                    minX = v.x;
                else if (v.x > maxX)
                    maxX = v.x;
                if (v.y < minY)
                    minY = v.y;
                else if (v.y > maxY)
                    maxY = v.y;
                if (v.z < minZ)
                    minZ = v.z;
                else if (v.z > maxZ)
                    maxZ = v.z;
            }
            Minimums = new Vector3(minX, minY, minZ);
            Maximums = new Vector3(maxX, maxY, maxZ);
        }
    }
}
