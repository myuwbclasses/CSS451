﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using LightJson;
using UnityEngine;
using Model;

namespace Util
{
    /// <summary>
    /// Utility for dumping out details of the scene hierarchy (for debugging).
    /// </summary>
    public class GameObjectDebug
    {
        public static JsonArray GetHierarchyDetails(SceneNode root)
        {
            var nodes = root.Descendants();
            var array = new JsonArray();
            foreach (var node in root.Descendants())
            {
                array.Add(GetObjectDetails(node));
            }
            return array;
        }

        public static JsonObject GetObjectDetails(Node node)
        {
            if (node is SceneNode)
            {
                return GetObjectDetails((SceneNode)node);
            }
            else
            {
                return GetObjectDetails((NodePrimitive)node);
            }
        }

        public static JsonObject GetObjectDetails(SceneNode node)
        {
            return AddBasicObjectDetails(new JsonObject(), node);
        }

        public static JsonObject AddBasicObjectDetails(JsonObject details, Node node)
        {
            // Get the basic data.
            details
                .Add("name", node.gameObject.name)
                .Add("type", node.GetType().Name)
                .Add("id", node.gameObject.GetHashCode());

            var parentNode = node.GetParentSceneNode();
            if (parentNode != null)
            {
                details
                    .Add("parentName", node.GetParentSceneNode().gameObject.name)
                    .Add("parentId", node.GetParentSceneNode().gameObject.GetHashCode());
            }

            details
                .Add(
                    "pivot",
                    new JsonObject()
                        .Add("x", node.Pivot.x)
                        .Add("y", node.Pivot.y)
                        .Add("z", node.Pivot.z));

            details
                .Add(
                    "localScale",
                    new JsonObject()
                        .Add("x", node.transform.localScale.x)
                        .Add("y", node.transform.localScale.y)
                        .Add("z", node.transform.localScale.z));
            details
                .Add(
                    "localRotation",
                    new JsonObject()
                        .Add("x", node.transform.localEulerAngles.x)
                        .Add("y", node.transform.localEulerAngles.x)
                        .Add("z", node.transform.localEulerAngles.x));

            details
                .Add(
                    "localPosition",
                    new JsonObject()
                        .Add("x", node.transform.localPosition.x)
                        .Add("y", node.transform.localPosition.y)
                        .Add("z", node.transform.localPosition.z));

            var matrix = node.GetMatrix();

            // Get a world position
            var worldPos = matrix.MultiplyPoint(node.transform.localPosition);
            details
                .Add(
                    "worldPosition",
                    new JsonObject()
                        .Add("x", worldPos.x)
                        .Add("y", worldPos.y)
                        .Add("z", worldPos.z));

            return details;
        }


        public static JsonObject GetObjectDetails(NodePrimitive node)
        {
            var details = AddBasicObjectDetails(new JsonObject(), node);

            var matrix = node.GetMatrix();
            var mesh = node.gameObject.GetComponent<MeshFilter>();
            var vertices = mesh.mesh.vertices;
            var triangles = mesh.mesh.triangles;

            details.Add("triangleCount", triangles.Length / 3.0f);
            details.Add("vertexCount", vertices.Length);

            details.Add(
                "localVertexStats",
                new JsonObject()
                    .Add("x", GetValueStats(vertices.Select(v => v.x)))
                    .Add("y", GetValueStats(vertices.Select(v => v.y)))
                    .Add("z", GetValueStats(vertices.Select(v => v.z))));


            var wVertices = vertices.Select(v => matrix.MultiplyPoint(v));
            details.Add(
                "worldVertexStats",
                new JsonObject()
                    .Add("x", GetValueStats(wVertices.Select(v => v.x)))
                    .Add("y", GetValueStats(wVertices.Select(v => v.y)))
                    .Add("z", GetValueStats(wVertices.Select(v => v.z))));

            return details;
        }

        private static JsonObject GetValueStats(IEnumerable<float> values)
        {
            var min = values.Min();
            var max = values.Max();
            return new JsonObject()
                .Add("min", min)
                .Add("max", max)
                .Add("range", max - min)
                .Add("center", (min + max) / 2.0f);
        }
    }
}
