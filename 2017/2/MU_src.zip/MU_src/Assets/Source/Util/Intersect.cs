﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Util
{
    /// <summary>
    /// Utilities for intersection math.
    /// </summary>
    public class Intersect
    {
        public static bool TriangleToTriangle(
            Vector3 t1a, Vector3 t1b, Vector3 t1c,
            Vector3 t2a, Vector3 t2b, Vector3 t2c)
        {
            if (LineSegmentToTriangle(t1a, t1b, t2a, t2b, t2c).HasValue ||
                LineSegmentToTriangle(t1a, t1c, t2a, t2b, t2c).HasValue ||
                LineSegmentToTriangle(t1b, t1c, t2a, t2b, t2c).HasValue ||
                LineSegmentToTriangle(t2a, t2b, t1a, t1b, t1c).HasValue ||
                LineSegmentToTriangle(t2a, t2c, t1a, t1b, t1c).HasValue ||
                LineSegmentToTriangle(t2b, t2c, t1a, t1b, t1c).HasValue)
            {
                return true;
            }

            // TODO: should check of triagles are co-planar
            return false;
        }

        private static Vector3? LineSegmentToTriangle(
            Vector3 lineStart, Vector3 lineEnd,
            Vector3 triangleV0, Vector3 triangleV1, Vector3 triangleV2)
        {
            var v = lineEnd - lineStart;
            var hit = RayToTriangle(lineStart, v.normalized, triangleV0, triangleV1, triangleV2);
            if (hit.HasValue && (hit.Value - lineStart).magnitude <= v.magnitude)
            {
                return hit;
            }
            return null;
        }

        /// <summary>
        /// Determine if a ray hits a triangle.
        /// </summary>
        public static Vector3? RayToTriangle(
            Vector3 lineStart, Vector3 lineVector,
            Vector3 triangleV0, Vector3 triangleV1, Vector3 triangleV2,
            float epsilon = 0.0000001f)
        {
            // The algorithm was found here:
            // https://courses.cs.washington.edu/courses/cse457/09au/lectures/triangle_intersection.pdf
            
            var tNormal = Vector3.Cross(triangleV1 - triangleV0, triangleV2 - triangleV0).normalized;
            var pIntersect = LineToPlane(lineStart, lineVector, tNormal, triangleV0);
            if (pIntersect.HasValue)
            {
                var q = pIntersect.Value;
                if (Vector3.Dot(Vector3.Cross(triangleV1 - triangleV0, q - triangleV0), tNormal) >= 0.0f &&
                    Vector3.Dot(Vector3.Cross(triangleV2 - triangleV1, q - triangleV1), tNormal) >= 0.0f &&
                    Vector3.Dot(Vector3.Cross(triangleV0 - triangleV2, q - triangleV2), tNormal) >= 0.0f)
                {
                    return q;
                }
            }
            return null;
        }
        
        /// <summary>
        ///     Returns the point on the given raw closest to point.
        /// </summary>
        public static Vector3 ClosestPointFromRayToPoint(Vector3 point, Vector3 rayStart, Vector3 rayDirection)
        {
            var V = rayDirection;
            var VA = point - rayStart;
            float d = Vector3.Dot(VA, V);

            // If the closest point is before the start of the ray return the origin.
            if (d < 0)
            {
                return rayStart;
            }

            return rayStart + V * d;
        }

        public static Vector3? LineToPlane(Vector3 linePoint, Vector3 lineDirection, Vector3 planeNormal, Vector3 planePoint)
        {
            var dotNumerator = Vector3.Dot((planePoint - linePoint), planeNormal);
            var dotDenominator = Vector3.Dot(lineDirection, planeNormal);
            if (dotDenominator != 0.0f)
            {
                var length = dotNumerator / dotDenominator;
                return linePoint + length * lineDirection;
            }
            return null;
        }

    }
}
