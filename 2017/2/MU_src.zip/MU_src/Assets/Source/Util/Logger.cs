﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Util
{
    public enum LogLevel { Debug, Info, Warn, Error };

    /// <summary>
    ///     Utility for logging information and messages.
    ///     Logs will go both to file and the unity debug console.
    /// </summary>
    public class Logger
    {
        private static readonly string LogFilePath = "motus-unitatas.log";
        private static volatile TextWriter _logOutput = null;

        public static void Debug(string format, params object[] args)
        {
            Log(LogLevel.Debug, null, format, args);
        }

        public static void Info(string format, params object[] args)
        {
            Log(LogLevel.Info, null, format, args);
        }

        public static void Warn(string format, params object[] args)
        {
            Log(LogLevel.Warn, null, format, args);
        }

        public static void Warn(Exception e, string format, params object[] args)
        {
            Log(LogLevel.Warn, e, format, args);
        }

        public static void Error(string format, params object[] args)
        {
            Log(LogLevel.Error, null, format, args);
        }

        public static void Error(Exception e, string format, params object[] args)
        {
            Log(LogLevel.Error, e, format, args);
        }

        public static void Log(LogLevel lvl, string format, params object[] args)
        {
            Log(lvl, null, format, args);
        }

        public static void Log(LogLevel lvl, Exception e, string format, params object[] args)
        {
            string msg = Format(lvl, e, format, args);

            UnityEngine.Debug.Log(msg);

            var writer = GetLogOutput();
            if (writer != null)
            {
                try
                {
                    writer.WriteLine(msg);
                    writer.Flush();
                }
                catch (Exception)
                {
                }
            }
        }

        private static string Format(LogLevel lvl, Exception e, string format, object[] args)
        {
            var sb = new StringBuilder();
            sb.AppendFormat("[{0:HH:mm:ss.FFFF}] {1} - ", DateTime.Now, lvl.ToString());
            try
            {
                sb.AppendFormat(format, args);
            }
            catch (Exception fe)
            {
                sb.Append("Invalid log format: " + format + " -> " + fe.Message);
            }

            if (e != null)
            {
                sb.AppendLine();
                sb.Append(e.ToString());
            }

            return sb.ToString();
        }

        private static TextWriter GetLogOutput()
        {
            if (_logOutput == null)
            {
                try
                {
                    var fPath = Path.GetFullPath(LogFilePath);
                    UnityEngine.Debug.Log("Writing output to: " + fPath);
                    var logFH = File.Open(fPath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                    _logOutput = new StreamWriter(logFH, Encoding.UTF8);
                    _logOutput.WriteLine("======================================================");
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.Log("ERROR: Couldn't open file for logging: " + e);
                }
            }
            return _logOutput;
        }
    }
}
