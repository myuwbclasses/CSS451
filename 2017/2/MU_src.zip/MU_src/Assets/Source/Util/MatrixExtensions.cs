﻿using System;

using UnityEngine;

namespace Util
{
    public static class MatrixExtensions
    {
        public static Vector3 GetPosition(this Matrix4x4 m)
        {
            Vector4 x =  m.GetColumn(3);
            return x;
        }

        public static Quaternion GetRotation(this Matrix4x4 m)
        {
            return Quaternion.LookRotation(m.GetColumn(2), m.GetColumn(1));
        }

        public static Vector3 GetScale(this Matrix4x4 m)
        {
            return new Vector3(
                m.GetColumn(0).magnitude,
                m.GetColumn(1).magnitude,
                m.GetColumn(2).magnitude);
        }
    }
}

