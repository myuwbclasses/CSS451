﻿using System;
using UnityEngine;

namespace Util
{
    public class MouseDrag
    {
        public int Button { get; private set; }
        public bool Active { get; private set; }
        public bool WasDrug { get; private set; }
        public Vector3 LastPosition { get; private set; }
        public Vector3 CurrentPosition { get; private set; }

        private Func<bool> _preCondition;

        public MouseDrag(int button, Func<bool> preCondition = null)
        {
            Button = button;
            Active = false;
            WasDrug = false;
            LastPosition = Vector3.zero;
            CurrentPosition = Vector3.zero;
            _preCondition = (preCondition == null) ? (() => true) : preCondition;
        }

        public void Reset()
        {
            Active = false;
            WasDrug = false;
        }

        public bool Update()
        {
            WasDrug = false;
            if (_preCondition() && Input.GetMouseButton(Button))
            {
                if (Active)
                {
                    LastPosition = CurrentPosition;
                    CurrentPosition = Input.mousePosition;
                    WasDrug = true;
                    return true;
                }
                else
                {
                    Active = true;
                    CurrentPosition = Input.mousePosition;
                }
            }
            else
            {
                Reset();
            }
            return false;
        }
    }
}

