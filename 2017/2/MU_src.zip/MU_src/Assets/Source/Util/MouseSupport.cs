﻿using System;
using UnityEngine;

namespace Util
{
    /// <summary>
    /// Utility for handling mouse events.
    /// </summary>
    public class MouseSupport
    {
        /// <summary>
        /// Mouse click checking will happen in layers 1 through 7 only.
        /// The value below is a mask for the following 7 layers.
        /// This allows the CreationTarget to "live" outside of the layers checked for mouse clicks.
        /// </summary>
        public static readonly int RayCastLayerCheck = (1 << 8) - 1;

        /// <summary>
        /// The maximum distance to check for on mouse clicks.
        /// </summary>
        public static readonly int RayCastLengthCheck = 2000;

        /// <summary>
        /// Get the object hit from the current mouse position
        /// </summary>
        public static RaycastHit? GetRaycastHit()
        {
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, RayCastLengthCheck, RayCastLayerCheck))
            {
                return hit;
            }
            return null;
        }
    }
}