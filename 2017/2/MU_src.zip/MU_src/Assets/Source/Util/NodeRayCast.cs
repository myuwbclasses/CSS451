﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

using Model;
using UnityEngine;
using Util.Collide;

using Logger = Util.Logger;

namespace Util
{
    public class NodeRayCastHit
    {
        public Ray ray;
        public NodePrimitive node;
        public Vector3 hit;
    }

    public class NodeRayCast
    {

        public static NodeRayCastHit GetHit2(IEnumerable<NodePrimitive> nodes)
        {
            var sw = new Stopwatch();
            sw.Start();

            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            // Find the hit closes to the camera start.
            NodeRayCastHit result = null;
            float d = 0.0f;

            foreach (var node in nodes)
            {
                var collider = MeshObjectCollider.Get(node.gameObject);
                var hit = collider.Raycast(ray);
                if (hit.HasValue)
                {
                    if (result == null)
                    {
                        result = new NodeRayCastHit { ray = ray, node = node, hit = hit.Value };
                        d = (hit.Value - ray.origin).magnitude;
                    }
                    else
                    {
                        var hitD = (hit.Value - ray.origin).magnitude;
                        if (hitD < d)
                        {
                            result = new NodeRayCastHit { ray = ray, node = node, hit = hit.Value };
                            d = hitD;
                        }
                    }
                }
            }

            sw.Stop();
            Logger.Info("NodeRawCast.GetHit2 took {0} ms.", sw.Elapsed.TotalMilliseconds);

            return result;
        }

        /// <summary>
        /// Find a hit point on a node primitive.
        /// TODO: This can be slow it checks the mesh directly.
        ///       It is taking about 4ms for me right now.
        /// </summary>
        public static NodeRayCastHit GetHit(IEnumerable<NodePrimitive> nodes)
        {
            var sw = new Stopwatch();
            sw.Start();

            // Find the hit closes to the camera start.
            NodeRayCastHit result = null;
            float d = 0.0f;

            EachNodeHit(nodes, (node, hit, ray) =>
            {
                if (result == null)
                {
                    result = new NodeRayCastHit { ray = ray, node = node, hit = hit };
                    d = (hit - ray.origin).magnitude;
                }
                else 
                {
                    var hitD = (hit - ray.origin).magnitude;
                    if (hitD < d)
                    {
                        result = new NodeRayCastHit { ray = ray, node = node, hit = hit };
                        d = hitD;
                    }
                }
            });

            sw.Stop();
            Logger.Info("NodeRawCast.GetHit took {0} ms.", sw.Elapsed.TotalMilliseconds);

            return result;
        }

        public static void EachNodeHit(IEnumerable<NodePrimitive> nodes, Action<NodePrimitive, Vector3, Ray> onHit)
        {
            var ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            foreach (var n in nodes)
            {
                EachNodeHit(n, ray, onHit);
            }
        }

        public static void EachNodeHit(NodePrimitive node, Ray ray, Action<NodePrimitive, Vector3, Ray> onHit)
        {
            var iMatrix = node.GetInverseMatrix();
            var matrix = node.GetMatrix();
            var localRayOrigin = iMatrix.MultiplyPoint(ray.origin);
            var localRayPoint = iMatrix.MultiplyPoint(ray.origin + ray.direction);
            var localRayVector = (localRayPoint - localRayOrigin).normalized;

            var meshFilter = node.GetComponent<MeshFilter>();
            var mesh = meshFilter.mesh;
            var vertices = mesh.vertices;
            var triangles = mesh.triangles;
            
            for (int i = 0; i < triangles.Length; i += 3)
            {
                var v0 = vertices[triangles[i]];
                var v1 = vertices[triangles[i + 1]];
                var v2 = vertices[triangles[i + 2]];
                var hit = Intersect.RayToTriangle(localRayOrigin, localRayVector, v0, v1, v2);
                if (hit.HasValue)
                {
                    onHit(node, matrix.MultiplyPoint(hit.Value), ray);
                }
            }
        }
    }
}
