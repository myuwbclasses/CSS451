﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Util
{
    /// <summary>
    /// Utility that allows the value of a variable to be watched.
    /// It allows components to subscribe to the value of the variable and perform
    /// actions whenever the value changes. This helps decouple UI updates
    /// from model changes.
    /// 
    /// Note: this class is not thread safe.
    /// </summary>
    public class WatchableAttribute<T>
    {
        /// <summary>
        /// The current Value.
        /// </summary>
        private T mValue;

        /// <summary>
        /// The listeners which are called when a value changes.
        /// </summary>
        private List<Action<T, T>> mListeners = new List<Action<T, T>>();

        /// <summary>
        /// Flag to disable updates.
        /// This is used to keep circular updates from happening.
        /// </summary>
        private bool _enabled = true;

        /// <summary>
        /// Create a new WatchableAttribute.
        /// </summary>
        /// <param name="value">Value.</param>
        public WatchableAttribute(T value)
        {
            mValue = value;
        }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>The value.</value>
        public T Value
        {
            get { return mValue; }
            set
            {
                if (_enabled)
                {
                    _enabled = false;
                    try
                    {
                        if (!ValuesEqual(mValue, value))
                        {
                            T oldValue = mValue;
                            mValue = value;

                            /// Trigger any listeners.
                            foreach (var listener in mListeners)
                            {
                                listener(oldValue, mValue);
                            }
                        }
                    }
                    finally
                    {
                        _enabled = true;
                    }
                }
            }
        }

        /// <summary>
        /// Add a listener.
        /// </summary>
        /// <param name="listener">Listener.</param>
        public void AddListener(Action<T, T> listener)
        {
            mListeners.Add(listener);
        }

        /// <summary>
        /// Remove a listener.
        /// </summary>
        /// <param name="listener">Listener.</param>
        public void RemoveListener(Action<T, T> listener)
        {
            mListeners.Remove(listener);
        }

        private bool ValuesEqual(T v1, T v2)
        {
            if (v1 == null)
            {
                return v2 == null;
            }
            else
            {
                return v1.Equals(v2);
            }
        }
    }
}
